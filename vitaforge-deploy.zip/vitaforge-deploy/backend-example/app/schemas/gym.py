"""
VitaForge AI — Gym Dashboard Schemas
─────────────────────────────────────────────────────
Mirrors src/lib/api-types.ts on the frontend. Keep field
names in snake_case here; the frontend camelCase mapping
(where needed) happens at the fetch boundary.
─────────────────────────────────────────────────────
"""

from typing import Literal, Optional
from pydantic import BaseModel

Tone = Literal["default", "warn", "good"]
MemberStatus = Literal["active", "risk", "new", "paused"]
Plan = Literal["Starter", "Pro", "Scale", "Enterprise"]


class KpiOut(BaseModel):
    label: str
    value: str
    delta: Optional[str] = None
    tone: Optional[Tone] = "default"


class TimeSeriesPointOut(BaseModel):
    label: str
    value: float


class MemberOut(BaseModel):
    id: str
    initials: str
    name: str
    plan: Plan
    status: MemberStatus
    streak: str
    score: int
    joined_at: str


class GymDashboardOut(BaseModel):
    gym_name: str
    gym_city: str
    plan_label: str
    kpis: list[KpiOut]
    weekly_activity: list[TimeSeriesPointOut]
    recent_members: list[MemberOut]
    churn_risk_members: list[MemberOut]
    leaderboard: list[MemberOut]


class AiInsightOut(BaseModel):
    id: str
    tone: Tone
    title: str
    body: str
    action_label: str
    action_route: Optional[str] = None


class AiCopilotRequest(BaseModel):
    role: Literal["owner", "trainer", "superadmin", "member"]
    message: str
    gym_id: Optional[str] = None


class AiCopilotReply(BaseModel):
    reply: str
