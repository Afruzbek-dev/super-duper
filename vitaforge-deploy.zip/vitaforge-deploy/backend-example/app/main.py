"""
VitaForge AI — Backend Example Entrypoint
─────────────────────────────────────────────────────
This is a MINIMAL standalone FastAPI app so you can run
the gym dashboard endpoint immediately and see the frontend
talk to a real backend. It is NOT the full VitaForge backend
(no DB, no auth, no ARQ workers) — just enough to prove the
frontend↔backend contract works end-to-end.

Run:
    cd backend-example
    pip install fastapi uvicorn --break-system-packages
    uvicorn app.main:app --reload --port 8000

Then set in your Next.js .env.local:
    NEXT_PUBLIC_API_URL=http://localhost:8000
─────────────────────────────────────────────────────
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import gym

app = FastAPI(title="VitaForge AI — API (example)")

# Allow the Next.js dev server to call this API directly.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(gym.router, prefix="/api/v1/gym", tags=["gym"])


@app.get("/health")
async def health():
    return {"status": "ok"}
