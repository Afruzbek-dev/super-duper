"""
VitaForge AI — Gym Router (Owner Dashboard)
─────────────────────────────────────────────────────
Reference implementation for GET /api/v1/gym/dashboard.
Replace the mock query functions with real async SQLAlchemy
calls against Supabase Postgres (see project memory: async
SQLAlchemy + Supabase is the existing backend stack).

Wire this into your FastAPI app with:
    from app.routers import gym
    app.include_router(gym.router, prefix="/api/v1/gym", tags=["gym"])
─────────────────────────────────────────────────────
"""

from fastapi import APIRouter, Depends, HTTPException

from app.schemas.gym import (
    GymDashboardOut,
    KpiOut,
    TimeSeriesPointOut,
    MemberOut,
    AiCopilotRequest,
    AiCopilotReply,
)

# TODO: replace with your real auth dependency
# from app.core.auth import get_current_owner
# router = APIRouter(dependencies=[Depends(get_current_owner)])
router = APIRouter()


@router.get("/dashboard", response_model=GymDashboardOut)
async def get_gym_dashboard(
    # gym_id: str = Depends(get_current_gym_id),
    # db: AsyncSession = Depends(get_db),
):
    """
    Returns the full Owner Dashboard payload in one call:
    KPIs, weekly activity chart data, recent members, churn
    risk list, and the weekly leaderboard.

    Real implementation sketch:
        gym = await db.get(Gym, gym_id)
        members = await get_members_for_gym(db, gym_id)
        risk_members = [m for m in members if m.churn_score > 0.6]
        leaderboard = sorted(members, key=lambda m: -m.score)[:4]
        weekly = await get_weekly_activity(db, gym_id)
    """
    # ─── MOCK DATA — replace with real DB queries ──────
    members = [
        MemberOut(id="1", initials="JT", name="Jasur Toshmatov", plan="Pro", status="active", streak="🔥 14 kun", score=2340, joined_at="12 fev, 2026"),
        MemberOut(id="2", initials="NM", name="Nilufar Mirzaeva", plan="Starter", status="active", streak="🔥 7 kun", score=1180, joined_at="3 mar, 2026"),
        MemberOut(id="3", initials="DR", name="Doniyor Raxmonov", plan="Pro", status="risk", streak="0 kun", score=340, joined_at="20 yan, 2026"),
        MemberOut(id="4", initials="MA", name="Mohira Aliyeva", plan="Scale", status="new", streak="🌱 2 kun", score=90, joined_at="24 iyun, 2026"),
    ]
    risk_members = [m for m in members if m.status == "risk"]
    leaderboard = sorted([m for m in members if m.status == "active"], key=lambda m: -m.score)

    return GymDashboardOut(
        gym_name="FitZone Gym",
        gym_city="Yunusobod, Toshkent",
        plan_label="PRO TARIF",
        kpis=[
            KpiOut(label="RETENTION (30 KUN)", value="73%", delta="↑ 12% o'tgan oydan"),
            KpiOut(label="JAMI A'ZOLAR", value="214", delta="+18 yangi"),
            KpiOut(label="CHURN RISK", value=str(len(risk_members)), delta="↓ kuzatuv kerak", tone="warn"),
            KpiOut(label="FAOL BUGUN", value="87", delta="41% DAU"),
        ],
        weekly_activity=[
            TimeSeriesPointOut(label="Du", value=58), TimeSeriesPointOut(label="Se", value=72),
            TimeSeriesPointOut(label="Ch", value=65), TimeSeriesPointOut(label="Pa", value=88),
            TimeSeriesPointOut(label="Ju", value=80), TimeSeriesPointOut(label="Sh", value=75),
            TimeSeriesPointOut(label="Ya", value=70),
        ],
        recent_members=members,
        churn_risk_members=risk_members,
        leaderboard=leaderboard,
    )


@router.post("/copilot", response_model=AiCopilotReply)
async def ai_copilot_chat(payload: AiCopilotRequest):
    """
    Proxies a message to Claude with role-specific system
    context (owner/trainer/superadmin/member), and returns
    the reply as plain text for the AiCopilot chat panel.

    Real implementation sketch:
        system_prompt = build_copilot_prompt(payload.role, payload.gym_id)
        response = await claude_client.messages.create(
            model="claude-sonnet-4-6",
            system=system_prompt,
            messages=[{"role": "user", "content": payload.message}],
            max_tokens=500,
        )
        return AiCopilotReply(reply=response.content[0].text)
    """
    if not payload.message.strip():
        raise HTTPException(status_code=400, detail="Message bo'sh bo'lishi mumkin emas")

    # ─── MOCK REPLY — replace with real Claude call ────
    return AiCopilotReply(
        reply=f"[{payload.role}] Savolingizni tushundim: \"{payload.message}\". "
        "Bu yerga Claude API javobi keladi."
    )
