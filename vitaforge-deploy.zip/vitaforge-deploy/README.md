# VitaForge AI — ishga tushirish

Bu loyiha to'liq ishlaydigan Next.js 15+ TypeScript ilova, **Supabase Auth** bilan haqiqiy autentifikatsiya qilingan — build va server orqali sinovdan o'tgan.

## 1. Supabase loyihash

1. [supabase.com](https://supabase.com)da yangi loyiha yarating (bepul, tez)
2. **Settings → API** dan `Project URL` va `anon public` kalitni oling
3. **SQL Editor**ga o'ting, `supabase/migrations/0001_profiles.sql` faylining butun tarkibini joylashtirib ishga tushiring — bu `profiles` jadvalini, avtomatik profil yaish trigger'ini va rol-eskalatsiyaga qarshi himoyani o'rnatadi

## 2. Muhit o'zgaruvchilari

```bash
cp .env.local.example .env.local
```

`.env.local` fayl ochib, Supabase ma'lumotlaringizni kiriting:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key
```

## 3. Frontend'ni ishga tushirish

```bash
npm install
npm run dev
```

Brauzerda: **http://localhost:3000** — avtomatik `/login`ga yo'naltiradi.

## 4. Ro'yxatdan o'tish / Kirish

**Owner / Trainer / Member** — "Ro'yxatdan o'tish" tabida ism, email, parol va rolni tanlab haqiqiy hisob yarating. Supabase email tasdiqlashni talab qilishi mumkin (loyiha sozlamalariga bog'liq) — agar shunday bo'lsa, pochtangizga havola kelad, keyin "Kirish" tabidan kiring.

**Super Admin** — bu rol **hech qachon o'z-o'zidan ro'yxatdan o'tib bo'lmaydi** (xavfsizlik uchun qasddan cheklangan). Buni bir marta qo'lda sozlash kerak:

1. Supabase **Dashboard → Authentication → Users → Add User** orqali quyidagi hisobni yarating ("Auto Confirm User" belgisini qo'ying):
   ```
   Email:  admin@vitaforge.uz
   Parol:  VitaForge#2026
   ```
2. **SQL Editor**da ishga tushiring:
   ```sql
   update public.profiles
   set role = 'superadmin'
   where email = 'admin@vitaforge.uz';
   ```
3. Endi shu email/parol bilan "Kirish" tabidan kiring — Super Admin sifatida tanilasiz

Login sahifasida "🛡️ Super Admin demo login" tugmasi orqali ham shu ma'lumotlarni ko'rish mumkin.

## 5. Rol almashtirish (kirgandan keyin)

Sahifa tepasidagi rol tugmalari orqali Owner/Trainer/Member orasida erkin almashish mumkin (demo maqsadida). **Super Admin faqat haqiqiy login orqali kirilgan bo'lsa** rol tugmalari orasida ko'rinadi — bu `profiles.role` qiymatidan aniqlanadi, boshqa foydalanuvchilar Super Admin'ga o'tib bo'lmaydi.

Chiqish uchun: Desktop'da sidebar pastida "🚪 Chiqish", mobil (Member) profilida ham xuddi shunday tugma bor.

## 6. Real backend bilan sinash (ixtiyoriy, alohida namuna)

```bash
cd backend-example
pip install fastapi uvicorn --break-system-packages
uvicorn app.main:app --reload --port 8000
```

`http://localhost:3000/owner/dashboard` — bu sahifa FastAPI backend'idan ma'lumot oladi (login talab qilinmaydi, mustaqil namuna sifatida qoldirilgan).

## 7. Production build

```bash
npm run build
npm start
```

## Papka tuzilishi

```
src/
├── app/
│   ├── layout.tsx
│   ├── page.tsx                # AuthGuard bilan o'ralgan — session bo'lmasa /login'ga
│   ├── login/page.tsx           # Kirish / Ro'yxatdan o'tish (Supabase)
│   ├── globals.css
│   └── owner/dashboard/
│       └── page.tsx             # Real FastAPI backend'ga ulangan alohida namuna
├── components/
│   ├── VitaForgeKit.tsx         # Barcha UI + VitaForgeApp (auth-aware)
│   └── AuthGuard.tsx            # Client-side route guard
└── lib/
    ├── auth.ts                  # Supabase Auth: signIn, signUp, session, profiles
    ├── supabase.ts             # Supabase browser client
    ├── api.ts                  # FastAPI uchun fetch wrapper
    └── api-types.ts           # Backend bilan bir xil TypeScript turlari

supabase/
└── migrations/
    └── 0001_profiles.sql       # profiles jadvali + trigger'lar + RLS

backend-example/
└── app/                                # Minimal FastAPI namunasi (Supabase JWT tekshiruvi hali yo'q)
```

## Xavfsizlik arxitekturasi (nima uchun shunday qurilgan)

- **Rol `profiles` jadvalida, JWT metadata'da emas** — chunki `user_metadata`ni foydalanuvchi o'zi `updateUser()` orqali o'zgartira oladi, bu esa o'z-o'zini superadmin qilib qo'yish xavfini beradi
- **Rol-eskalatsiyaga qarshi trigger** — `profiles.role` ustunini PostgREST orqali (ya'ni ilovadan) o'zgartirib bo'lmaydi, faqat to'g'ridan-to'g'ri SQL orqali (administrator tomonidan)
- **Self-serve signup'da superadmin so'ralsa ham** — trigger uni avtomatik `member`ga tushiradi
- **RLS yoqilgan** — har bir foydalanuvchi faqat o'z profilini ko'ra oladi

## ⚠️ Keyingi qadam — production uchun

1. **Backend JWT tekshiruvi** — `backend-example/` hali Supabase JWT'ni tekshirmaydi. FastAPI'da buni qo'shish uchun:
   ```python
   from fastapi import Depends, HTTPException, Header
   import jwt

   async def get_current_user(authorization: str = Header(...)):
       token = authorization.replace("Bearer ", "")
       try:
           payload = jwt.decode(
               token,
               SUPABASE_JWT_SECRET,  # Settings → API → JWT Secret
               algorithms=["HS256"],
               audience="authenticated",
           )
           return payload  # contains 'sub' (user id), 'email', etc.
       except jwt.InvalidTokenError:
           raise HTTPException(status_code=401, detail="Yaroqsiz token")
   ```
2. **Telegram Mini App uchun** — Member roli Telegram orqali kirsa, alohida oqim kerak: `initData` → HMAC-SHA256 tekshiruv → Supabase'da mos foydalanuvchi topish/yaratish (loyiha arxitekturasida rejalashtirilgan)
3. **Email tasdiqlashni** production'da albatta yoqiq qoldiring (Supabase Dashboard'da standart yoqilgan)

## Texnik tafsilotlar

- **Next.js**: 15.5.20 · **React**: 18.3.1 · **TypeScript**: strict mode
- **Auth**: Supabase Auth (`@supabase/supabase-js`) — real email/parol, RLS bilan himoyalangan
- **Backend misoli**: FastAPI 0.139 + Pydantic v2 (asosiy loyihada async SQLAlchemy + Supabase ishlatiladi)
- **CORS**: `backend-example/app/main.py`da `localhost:3000` uchun sozlangan
- **Sinovdan o'tkazildi**: `npm run build` ✅(4 route) · `tsc --noEmit` ✅· login sahifasi (Sign In/Sign Up) server orqali render qilingani tasdiqlandi ✅· SQL migratsiya qo'lda ko'zdan kechirildi (bu muhitda Postgres yo'q, live Supabase'ga ulanib sinalmagan — o'zingizning loyihada sinab ko'ring)
