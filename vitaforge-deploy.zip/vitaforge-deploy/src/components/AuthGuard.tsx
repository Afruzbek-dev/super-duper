"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { colors, fonts } from "@/components/VitaForgeKit";

export function AuthGuard({ children }: { children: (session: NonNullable<ReturnType<typeof useAuth>["session"]>, logout: () => void) => React.ReactNode }) {
  const { session, ready, logout } = useAuth();
  const router = useRouter();

  React.useEffect(() => {
    if (ready && !session) {
      router.replace("/login");
    }
  }, [ready, session, router]);

  if (!ready || !session) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: colors.bg,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: colors.textDim,
          fontFamily: fonts.mono,
          fontSize: 12,
        }}
      >
        Yuklanmoqda...
      </div>
    );
  }

  return <>{children(session, logout)}</>;
}
