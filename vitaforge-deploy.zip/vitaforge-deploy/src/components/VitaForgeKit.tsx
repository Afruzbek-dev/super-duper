"use client";
/**
 * VitaForge AI — Complete Component Kit (single file)
 * ─────────────────────────────────────────────────────
 * Drop this file into your Next.js project as-is, e.g.:
 *   src/components/VitaForgeKit.tsx
 *
 * Usage:
 *   import { VitaForgeApp } from "@/components/VitaForgeKit";
 *   export default function Page() { return <VitaForgeApp />; }
 *
 * Everything is self-contained: design tokens, types, UI primitives,
 * gamification components, AI Copilot, desktop shell (Owner/Trainer/
 * SuperAdmin), mobile shell (Member), and full page content for every
 * role. Navigation is internal React state (no next/navigation needed),
 * so this works as a single embeddable app, a prototype, or a reference
 * to split into real Next.js routes later.
 *
 * Replace the "MOCK DATA" sections and the `onSend` / `fetchX` stubs
 * with real calls to your FastAPI backend.
 * ───────────────────────────────────────────────────── */

import React, { useState, useRef, useEffect } from "react";

/* ════════════════════════════════════════════════════════
   1. DESIGN TOKENS
   ════════════════════════════════════════════════════════ */

export const colors = {
  bg: "#080810",
  surface: "#0d0d16",
  surface2: "#13131c",
  surface3: "#1a1a26",
  border: "#1e1e2c",
  border2: "#2a2a3a",
  accent: "#E8FF47",
  accentDim: "rgba(232,255,71,0.10)",
  accentBorder: "rgba(232,255,71,0.30)",
  textHi: "#EEEEE8",
  textMid: "#9999ad",
  textLow: "#8888a0",
  textDim: "#52526a",
  good: "#5DCAA5",
  goodDim: "rgba(93,202,165,0.12)",
  bad: "#E24B4A",
  badDim: "rgba(226,75,74,0.12)",
  warn: "#E8C547",
  warnDim: "rgba(232,197,71,0.12)",
  info: "#7BB6E8",
  infoDim: "rgba(56,142,222,0.12)",
} as const;

export const fonts = {
  display: "'Unbounded', sans-serif",
  body: "'DM Sans', sans-serif",
  mono: "'JetBrains Mono', monospace",
} as const;

/* Inject fonts + resets once, client-side */
function GlobalStyles() {
  return (
    <style
      dangerouslySetInnerHTML={{
        __html: `
      @import url("https://fonts.googleapis.com/css2?family=Unbounded:wght@400;600;700;900&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;600&display=swap");
      * { box-sizing: border-box; }
      body { background: ${colors.bg}; }
      ::-webkit-scrollbar { width: 4px; height: 4px; }
      ::-webkit-scrollbar-thumb { background: ${colors.border2}; border-radius: 4px; }
      ::selection { background: rgba(232,255,71,0.25); }
    `,
      }}
    />
  );
}

/* ════════════════════════════════════════════════════════
   2. TYPES
   ════════════════════════════════════════════════════════ */

export type AppRole = "member" | "trainer" | "owner" | "superadmin";
export type MemberStatus = "active" | "risk" | "new" | "paused";

export interface Member {
  id: string; initials: string; name: string;
  plan: "Starter" | "Pro" | "Scale" | "Enterprise";
  status: MemberStatus; streak: string; score: number;
  adherence?: number; joinedAt: string;
}

export interface Badge { id: string; icon: string; label: string; unlocked: boolean; hint?: string; }
export interface Level { num: number; title: string; icon: string; xp: number; xpMin: number; xpMax: number; }
export interface StreakData { current: number; longest: number; label: string; week?: boolean[]; }
export type ChatRole = "user" | "ai";
export interface ChatMessage { id: string; role: ChatRole; text: string; }
export type InsightTone = "default" | "warn" | "good";
export interface AiInsight { id: string; tone: InsightTone; title: string; body: string; actionLabel: string; onAction?: () => void; }
export interface TimeSeriesPoint { label: string; value: number; }
export interface KpiCardData { label: string; value: string; delta?: string; tone?: "default" | "warn" | "good"; }
export interface NavItem { id: string; icon: string; label: string; }

/* ════════════════════════════════════════════════════════
   3. UI PRIMITIVES
   ════════════════════════════════════════════════════════ */

export function Card({ children, accent, warn, onClick, style }: {
  children: React.ReactNode; accent?: boolean; warn?: boolean; onClick?: () => void; style?: React.CSSProperties;
}) {
  const border = accent ? colors.accentBorder : warn ? "rgba(226,75,74,0.30)" : colors.border;
  const bg = accent ? colors.accentDim : warn ? "rgba(226,75,74,0.05)" : colors.surface;
  return (
    <div onClick={onClick} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 14, padding: "14px 16px", marginBottom: 10, cursor: onClick ? "pointer" : undefined, ...style }}>
      {children}
    </div>
  );
}

export function Button({ children, variant = "primary", size = "md", onClick, fullWidth, style }: {
  children: React.ReactNode; variant?: "primary" | "outline" | "ghost"; size?: "sm" | "md"; onClick?: () => void; fullWidth?: boolean; style?: React.CSSProperties;
}) {
  const base: React.CSSProperties = {
    fontFamily: fonts.body, fontWeight: 600, fontSize: size === "sm" ? 11 : 13,
    padding: size === "sm" ? "7px 12px" : "11px 18px", borderRadius: 11, cursor: "pointer",
    border: "none", width: fullWidth ? "100%" : undefined, textAlign: "center",
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, ...style,
  };
  const variants: Record<string, React.CSSProperties> = {
    primary: { background: colors.accent, color: colors.bg, boxShadow: "0 0 18px rgba(232,255,71,0.22)" },
    outline: { background: "transparent", border: `1px solid ${colors.border2}`, color: colors.textHi },
    ghost: { background: "transparent", color: colors.textMid },
  };
  return <button style={{ ...base, ...variants[variant] }} onClick={onClick}>{children}</button>;
}

type PillTone = "good" | "bad" | "mid" | "info" | "accent";
const PILL_STYLES: Record<PillTone, React.CSSProperties> = {
  good: { color: colors.good, background: colors.goodDim },
  bad: { color: colors.bad, background: colors.badDim },
  mid: { color: colors.warn, background: colors.warnDim },
  info: { color: colors.info, background: colors.infoDim },
  accent: { color: colors.bg, background: colors.accent },
};
export function Pill({ label, tone = "good" }: { label: string; tone?: PillTone }) {
  return <span style={{ ...PILL_STYLES[tone], fontSize: 10, fontFamily: fonts.mono, padding: "3px 10px", borderRadius: 999, display: "inline-block", whiteSpace: "nowrap" }}>{label}</span>;
}
export function statusTone(status: string): PillTone {
  if (status === "active" || status === "ok" || status === "Faol") return "good";
  if (status === "risk" || status === "Risk") return "bad";
  if (status === "new" || status === "Yangi") return "info";
  return "mid";
}

export function Avatar({ initials, size = "sm" }: { initials: string; size?: "sm" | "md" | "lg" }) {
  const dim = size === "lg" ? 48 : size === "md" ? 36 : 26;
  const fs = size === "lg" ? 17 : size === "md" ? 14 : 11;
  return (
    <div style={{ width: dim, height: dim, borderRadius: size === "lg" ? 14 : 8, background: "rgba(232,255,71,0.12)", color: colors.accent, display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: fonts.display, fontWeight: 700, fontSize: fs, flexShrink: 0 }}>
      {initials}
    </div>
  );
}

export function ProgressBar({ value, height = 6 }: { value: number; height?: number }) {
  return (
    <div style={{ height, background: colors.surface3, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ height: "100%", width: `${Math.min(100, value)}%`, background: colors.accent, borderRadius: 4, transition: "width .4s ease" }} />
    </div>
  );
}

export function MonoLabel({ children, color }: { children: React.ReactNode; color?: string }) {
  return <div style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: "1.5px", color: color ?? colors.textDim, marginBottom: 6 }}>{children}</div>;
}

export function KpiCard({ label, value, delta, tone = "default" }: KpiCardData) {
  const leftColor = tone === "warn" ? colors.bad : colors.accent;
  const deltaColor = delta?.startsWith("↑") ? colors.good : delta?.startsWith("↓") ? colors.bad : colors.textDim;
  return (
    <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderLeft: `2px solid ${leftColor}`, borderRadius: 12, padding: "16px 18px" }}>
      <div style={{ fontFamily: fonts.mono, fontSize: 10, color: colors.textDim, letterSpacing: 1, marginBottom: 8 }}>{label}</div>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 22, color: colors.textHi }}>{value}</div>
      {delta && <div style={{ fontFamily: fonts.mono, fontSize: 11, color: deltaColor, marginTop: 4 }}>{delta}</div>}
    </div>
  );
}

export function BarChart({ data, height = 110 }: { data: TimeSeriesPoint[]; height?: number }) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height, marginBottom: 8 }}>
        {data.map((d, i) => (
          <div key={i} style={{ flex: 1, height: `${max > 0 ? (d.value / max) * 100 : 0}%`, background: d.value === max ? colors.accent : colors.surface3, borderRadius: "3px 3px 0 0", minHeight: 4, transition: "height .3s ease" }} />
        ))}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        {data.map((d, i) => <div key={i} style={{ flex: 1, textAlign: "center", fontSize: 9, color: colors.textDim }}>{d.label}</div>)}
      </div>
    </div>
  );
}

export function InsightCard({ insight }: { insight: AiInsight }) {
  const leftColor = insight.tone === "warn" ? colors.bad : insight.tone === "good" ? colors.good : colors.accent;
  return (
    <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderLeft: `2px solid ${leftColor}`, borderRadius: 12, padding: 14, marginBottom: 10 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: colors.textHi, marginBottom: 4 }}>{insight.title}</div>
      <div style={{ fontSize: 11, color: colors.textMid, lineHeight: 1.6, marginBottom: 8 }}>{insight.body}</div>
      <button onClick={insight.onAction} style={{ background: "none", border: "none", fontFamily: fonts.mono, fontSize: 10, color: colors.accent, cursor: "pointer", letterSpacing: "0.5px", padding: 0 }}>
        {insight.actionLabel}
      </button>
    </div>
  );
}

export function Panel({ title, children, action, style }: { title?: React.ReactNode; children: React.ReactNode; action?: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 14, padding: "18px 20px", ...style }}>
      {title && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: fonts.mono, fontSize: 10, color: colors.textDim, letterSpacing: 1, marginBottom: 14 }}>
          <span>{title}</span>
          {action && <span style={{ cursor: "pointer", color: colors.accent }}>{action}</span>}
        </div>
      )}
      {children}
    </div>
  );
}

export function RowBetween({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", ...style }}>{children}</div>;
}
export function Divider() { return <div style={{ height: 1, background: colors.surface3, margin: "14px 0" }} />; }
export function RiskRow({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return <div onClick={onClick} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "9px 0", borderBottom: `1px solid ${colors.surface3}`, fontSize: 12, color: colors.textHi, cursor: onClick ? "pointer" : undefined }}>{children}</div>;
}

/* ════════════════════════════════════════════════════════
   4. GAMIFICATION
   ════════════════════════════════════════════════════════ */

const DAY_LABELS = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"];

export function WeekDots({ week }: { week: boolean[] }) {
  return (
    <div style={{ display: "flex", gap: 5, justifyContent: "space-between", marginTop: 10 }}>
      {week.map((done, i) => (
        <div key={i} style={{
          width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 8, fontFamily: fonts.mono, background: done ? colors.accent : colors.surface3,
          color: done ? colors.bg : colors.textDim, fontWeight: done ? 700 : 400,
          boxShadow: i === week.length - 1 && !done ? `0 0 0 2px rgba(232,255,71,0.4)` : undefined, flexShrink: 0,
        }}>{DAY_LABELS[i]}</div>
      ))}
    </div>
  );
}

export function StreakCard({ data }: { data: StreakData }) {
  return (
    <div style={{ background: "rgba(232,255,71,0.04)", border: `1px solid rgba(232,255,71,0.30)`, borderRadius: 13, padding: "14px 16px", marginBottom: 10 }}>
      <RowBetween>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 22 }}>🔥</span>
          <div>
            <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 16, color: colors.textHi }}>{data.current}</div>
            <div style={{ fontSize: 9, color: colors.textLow, marginTop: 1 }}>{data.label}</div>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: colors.accent }}>REKORD</div>
          <div style={{ fontSize: 13, fontWeight: 600, color: colors.textHi }}>{data.longest}</div>
        </div>
      </RowBetween>
      {data.week && <WeekDots week={data.week} />}
    </div>
  );
}

export function LevelBar({ level }: { level: Level }) {
  const pct = Math.round(((level.xp - level.xpMin) / (level.xpMax - level.xpMin)) * 100);
  return (
    <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 13, padding: "12px 14px", marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 18 }}>{level.icon}</span>
        <div>
          <div style={{ fontFamily: fonts.display, fontWeight: 600, fontSize: 12, color: colors.textHi }}>Daraja {level.num} · {level.title}</div>
          <div style={{ fontSize: 10, color: colors.textDim, fontFamily: fonts.mono }}>{level.xp} / {level.xpMax} XP</div>
        </div>
      </div>
      <ProgressBar value={pct} />
    </div>
  );
}

export function BadgeGrid({ badges, columns = 4 }: { badges: Badge[]; columns?: number }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${columns}, 1fr)`, gap: 8, margin: "8px 0 4px" }}>
      {badges.map((badge) => (
        <div key={badge.id} title={badge.unlocked ? "Ochilgan" : badge.hint ?? "Qulflangan"} style={{
          background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 12, padding: "10px 4px 8px",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 3, textAlign: "center",
          opacity: badge.unlocked ? 1 : 0.4, filter: badge.unlocked ? "none" : "grayscale(1)",
        }}>
          <span style={{ fontSize: 18 }}>{badge.unlocked ? badge.icon : "🔒"}</span>
          <span style={{ fontSize: 9, color: colors.textMid, lineHeight: 1.3 }}>{badge.label}</span>
          {!badge.unlocked && badge.hint && <span style={{ fontSize: 8, color: colors.textDim, fontFamily: fonts.mono }}>{badge.hint}</span>}
        </div>
      ))}
    </div>
  );
}

export function StreakHistogram({ data }: { data: TimeSeriesPoint[] }) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 90 }}>
        {data.map((d, i) => <div key={i} style={{ flex: 1, height: `${max > 0 ? (d.value / max) * 100 : 0}%`, background: d.value === max ? colors.accent : colors.surface3, borderRadius: "3px 3px 0 0", minHeight: 4 }} />)}
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
        {data.map((d, i) => <div key={i} style={{ flex: 1, textAlign: "center", fontSize: 8, color: colors.textDim, fontFamily: fonts.mono }}>{d.label}</div>)}
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   5. AI COPILOT (shared chat + insights)
   ════════════════════════════════════════════════════════ */

const QUICK_PROMPTS: Record<AppRole, string[]> = {
  owner: ["Churn xavfidagi a'zolarni ko'rsat", "Bu oy daromad qanday?", "Qaysi kun faollik eng past?"],
  trainer: ["Bugun kimga e'tibor berish kerak?", "Madina uchun xabar tayyorla", "Adherence pasayganlar ro'yxati"],
  superadmin: ["AI sarfi anomaliyalari bormi?", "Oxirgi 7 kunda churned gymlar", "Qaysi gym eng yuqori MRR?"],
  member: ["Bugungi mashqim qanday?", "Protein normam qancha?", "Osh necha kaloriya?"],
};

function simulateReply(text: string, role: AppRole): string {
  const t = text.toLowerCase();
  if (t.includes("churn") || t.includes("risk")) return "Hozirda 9 ta a'zo churn xavfida. Eng kritiklar: Doniyor (8 kun), Sevara (6 kun). Shaxsiy xabar yuborishni tavsiya qilaman.";
  if (t.includes("daromad") || t.includes("mrr")) return "Bu oy MRR $6,240 — o'tgan oydan 9.3% o'sdi. Eng ko'p daromad Pro reja a'zolaridan kelmoqda.";
  if (t.includes("osh") || t.includes("kaloriya")) return "O'rtacha porsiya osh (300g) — taxminan 540 kcal. Kunlik normangizning ~30% i.";
  if (t.includes("adherence") || t.includes("faollik")) return "O'rtacha adherence 81%. Eng past: Dilnoza (42%) — dastur murakkabligini kamaytirish tavsiya etiladi.";
  if (role === "superadmin") return "Platforma bo'yicha anomaliya aniqlandi: PowerFit Samarqand'da AI sarfi bu hafta 3.2x oshgan.";
  return "Tushundim. Aniqroq savol bering — raqamlar bilan javob beraman.";
}

export function AiCopilot({ role, initialMessages, insights, onSend }: {
  role: AppRole; initialMessages: ChatMessage[]; insights: AiInsight[]; onSend?: (text: string) => Promise<string>;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages]);

  const send = async (text: string) => {
    if (!text.trim()) return;
    setMessages((p) => [...p, { id: Date.now().toString(), role: "user", text }]);
    setInput("");
    setLoading(true);
    try {
      const reply = onSend ? await onSend(text) : await new Promise<string>((r) => setTimeout(() => r(simulateReply(text, role)), 700));
      setMessages((p) => [...p, { id: (Date.now() + 1).toString(), role: "ai", text: reply }]);
    } finally { setLoading(false); }
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 16 }}>
      <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 14, padding: "18px 20px", display: "flex", flexDirection: "column", height: 520 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(232,255,71,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>🤖</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: colors.textHi }}>AI Copilot</div>
            <div style={{ fontSize: 9, color: colors.good, fontFamily: fonts.mono }}>● online</div>
          </div>
        </div>
        <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingRight: 4 }}>
          {messages.map((m) => (
            <div key={m.id} style={{
              alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "78%",
              background: m.role === "user" ? colors.accent : colors.surface2, color: m.role === "user" ? colors.bg : colors.textHi,
              fontWeight: m.role === "user" ? 500 : 400, border: m.role === "user" ? "none" : `1px solid ${colors.border}`,
              borderRadius: m.role === "user" ? "13px 13px 4px 13px" : "13px 13px 13px 4px", padding: "10px 13px", fontSize: 12, lineHeight: 1.55,
            }}>{m.text}</div>
          ))}
          {loading && <div style={{ alignSelf: "flex-start", background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: "13px 13px 13px 4px", padding: "10px 13px", fontSize: 12, color: colors.textDim }}>● ● ●</div>}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", margin: "10px 0 0" }}>
          {QUICK_PROMPTS[role].map((p) => (
            <button key={p} onClick={() => send(p)} style={{ background: "transparent", border: `1px solid ${colors.border2}`, borderRadius: 999, padding: "4px 10px", fontSize: 10, color: colors.textMid, cursor: "pointer", fontFamily: fonts.body, whiteSpace: "nowrap" }}>{p}</button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(input)}
            placeholder="Savol yozing yoki harakatni tasdiqlang..." disabled={loading}
            style={{ flex: 1, background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: "10px 14px", fontSize: 12, color: colors.textHi, fontFamily: fonts.body, outline: "none" }} />
          <button onClick={() => send(input)} disabled={loading} style={{ width: 38, height: 38, background: colors.accent, border: "none", borderRadius: 10, color: colors.bg, fontSize: 16, cursor: "pointer", flexShrink: 0 }}>↑</button>
        </div>
      </div>
      <div>
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: colors.textDim, letterSpacing: 1, marginBottom: 12 }}>PROAKTIV TAVSIYALAR</div>
        {insights.map((i) => <InsightCard key={i.id} insight={i} />)}
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   6. DESKTOP SHELL (Owner / Trainer / SuperAdmin)
   ════════════════════════════════════════════════════════ */

const DESKTOP_NAV: Record<"owner" | "trainer" | "superadmin", NavItem[]> = {
  owner: [
    { id: "dashboard", icon: "📊", label: "Dashboard" }, { id: "members", icon: "👥", label: "A'zolar" },
    { id: "analytics", icon: "📈", label: "Analytics" }, { id: "challenge", icon: "🎯", label: "Challenge" },
    { id: "copilot", icon: "🤖", label: "AI Copilot" }, { id: "messages", icon: "📣", label: "Xabar yuborish" },
    { id: "settings", icon: "⚙️", label: "Sozlamalar" },
  ],
  trainer: [
    { id: "today", icon: "📅", label: "Bugun" }, { id: "clients", icon: "👥", label: "Mijozlarim" },
    { id: "schedule", icon: "🗓️", label: "Jadval" }, { id: "analytics", icon: "📈", label: "Analytics" },
    { id: "copilot", icon: "🤖", label: "AI Copilot" }, { id: "settings", icon: "⚙️", label: "Sozlamalar" },
  ],
  superadmin: [
    { id: "overview", icon: "📊", label: "Platforma" }, { id: "gyms", icon: "🏢", label: "Zallar" },
    { id: "billing", icon: "💳", label: "Billing" }, { id: "aiusage", icon: "🧠", label: "AI Usage" },
    { id: "copilot", icon: "🤖", label: "AI Copilot" }, { id: "settings", icon: "⚙️", label: "Sozlamalar" },
  ],
};

const PLAN_CARD: Record<"owner" | "trainer" | "superadmin", { label: string; value: string }> = {
  owner: { label: "JORIY REJA", value: "Pro · $69/oy" },
  trainer: { label: "DARAJA", value: "👑 Daraja 4 · Professional" },
  superadmin: { label: "PLATFORMA", value: "412 gym · $18.4k MRR" },
};

function DesktopSidebar({ role, page, onNavigate, userLabel, onLogout }: { role: "owner" | "trainer" | "superadmin"; page: string; onNavigate: (id: string) => void; userLabel?: string; onLogout?: () => void }) {
  const nav = DESKTOP_NAV[role];
  const plan = PLAN_CARD[role];
  return (
    <aside style={{ width: 220, background: "#0a0a12", borderRight: `1px solid ${colors.border}`, padding: "20px 16px", display: "flex", flexDirection: "column", flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18, padding: "0 4px" }}>
        <div style={{ width: 28, height: 28, background: colors.accent, borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: fonts.display, fontWeight: 900, color: colors.bg, fontSize: 13 }}>V</div>
        <span style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 14, color: colors.textHi }}>VitaForge</span>
      </div>
      <div style={{ fontFamily: fonts.mono, fontSize: 9, letterSpacing: 1, color: colors.textDim, marginBottom: 16, padding: "0 4px" }}>{role.toUpperCase()}</div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {nav.map((item) => {
          const active = item.id === page;
          return (
            <div key={item.id} onClick={() => onNavigate(item.id)} style={{
              display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 8, fontSize: 13, cursor: "pointer",
              color: active ? colors.accent : colors.textLow, background: active ? "rgba(232,255,71,0.08)" : "transparent", fontWeight: active ? 500 : 400,
            }}>
              <span style={{ width: 16, textAlign: "center" }}>{item.icon}</span>{item.label}
            </div>
          );
        })}
      </nav>
      <div style={{ flex: 1 }} />
      {userLabel && onLogout && (
        <>
          <div style={{ fontSize: 11, color: colors.textDim, padding: "0 4px", marginBottom: 8, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            👤 {userLabel}
          </div>
          <div
            onClick={onLogout}
            style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 8, fontSize: 12, cursor: "pointer", color: colors.bad, marginBottom: 10 }}
          >
            <span style={{ width: 16, textAlign: "center" }}>🚪</span> Chiqish
          </div>
        </>
      )}
      <div style={{ height: 1, background: colors.surface3, margin: "0 0 14px" }} />
      <div style={{ background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: 12 }}>
        <div style={{ fontFamily: fonts.mono, fontSize: 9, color: colors.textDim, letterSpacing: 1, marginBottom: 4 }}>{plan.label}</div>
        <div style={{ fontSize: 12, fontWeight: 600, color: colors.accent }}>{plan.value}</div>
      </div>
    </aside>
  );
}

/* ════════════════════════════════════════════════════════
   7. MOBILE SHELL (Member)
   ════════════════════════════════════════════════════════ */

const MOBILE_NAV: NavItem[] = [
  { id: "home", icon: "🏠", label: "Bosh" }, { id: "plan", icon: "💪", label: "Plan" },
  { id: "food", icon: "🥗", label: "Ovqat" }, { id: "top", icon: "🏆", label: "Top" },
  { id: "profile", icon: "👤", label: "Profil" },
];

function MobileTopBar({ onAction }: { onAction: () => void }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 14px 10px", flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <div style={{ width: 18, height: 18, background: colors.accent, borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: fonts.display, fontWeight: 900, fontSize: 9, color: colors.bg }}>V</div>
        <span style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 11, color: colors.textHi }}>VitaForge</span>
      </div>
      <button onClick={onAction} style={{ background: "rgba(232,255,71,0.10)", border: `1px solid rgba(232,255,71,0.28)`, borderRadius: 9, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, cursor: "pointer", position: "relative" }}>
        🤖<span style={{ position: "absolute", top: -2, right: -2, width: 6, height: 6, background: colors.accent, borderRadius: "50%" }} />
      </button>
    </div>
  );
}

function MobileBottomNav({ page, onNavigate }: { page: string; onNavigate: (id: string) => void }) {
  return (
    <nav style={{ display: "flex", borderTop: `1px solid ${colors.surface3}`, background: "rgba(13,13,22,0.97)", flexShrink: 0 }}>
      {MOBILE_NAV.map((item) => {
        const active = item.id === page;
        return (
          <div key={item.id} onClick={() => onNavigate(item.id)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "8px 0 10px", fontSize: 8, color: active ? colors.accent : colors.textDim, cursor: "pointer" }}>
            <span style={{ fontSize: 16 }}>{item.icon}</span>{item.label}
          </div>
        );
      })}
    </nav>
  );
}

export function MobileCard({ children, accent, warn, onClick, style }: { children: React.ReactNode; accent?: boolean; warn?: boolean; onClick?: () => void; style?: React.CSSProperties }) {
  const border = accent ? "rgba(232,255,71,0.30)" : warn ? "rgba(226,75,74,0.30)" : colors.border;
  const bg = accent ? "rgba(232,255,71,0.04)" : warn ? "rgba(226,75,74,0.05)" : colors.surface;
  return <div onClick={onClick} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 13, padding: "13px 14px", marginBottom: 9, cursor: onClick ? "pointer" : undefined, ...style }}>{children}</div>;
}

export function BigButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return <button onClick={onClick} style={{ width: "100%", background: colors.accent, color: colors.bg, fontFamily: fonts.body, fontWeight: 600, fontSize: 13, padding: 13, borderRadius: 12, border: "none", boxShadow: "0 0 18px rgba(232,255,71,0.25)", cursor: "pointer" }}>{children}</button>;
}

export function OutlineButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return <button onClick={onClick} style={{ width: "100%", border: `1px solid ${colors.border2}`, color: colors.textHi, fontSize: 12, padding: 11, borderRadius: 12, background: "transparent", cursor: "pointer", fontFamily: fonts.body }}>{children}</button>;
}

function AiChatSheet({ open, onClose, role }: { open: boolean; onClose: () => void; role: AppRole }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: "1", role: "ai", text: "Salom! Bugun nima haqida yordam bera olaman?" },
    { id: "2", role: "user", text: "Osh necha kaloriya?" },
    { id: "3", role: "ai", text: "O'rtacha porsiya osh (300g) — taxminan 540 kcal. Kunlik normangizning ~30% i." },
  ]);
  const [input, setInput] = useState("");
  const send = () => {
    if (!input.trim()) return;
    setMessages((p) => [...p, { id: Date.now().toString(), role: "user", text: input }]);
    const reply = simulateReply(input, role);
    setInput("");
    setTimeout(() => setMessages((p) => [...p, { id: (Date.now() + 1).toString(), role: "ai", text: reply }]), 600);
  };
  return (
    <>
      {open && <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 20 }} />}
      <div style={{ position: "fixed", left: 0, right: 0, bottom: 0, maxWidth: 430, margin: "0 auto", background: "#0b0b13", borderTop: `1px solid ${colors.border}`, borderRadius: "22px 22px 0 0", zIndex: 21, transform: open ? "translateY(0)" : "translateY(100%)", transition: "transform .22s ease", maxHeight: "80%", display: "flex", flexDirection: "column" }}>
        <div style={{ width: 36, height: 4, background: colors.border2, borderRadius: 3, margin: "10px auto 6px" }} />
        <RowBetween style={{ padding: "4px 16px 10px" }}>
          <span style={{ fontFamily: fonts.display, fontWeight: 600, fontSize: 12, color: colors.textHi }}>🤖 AI Trener</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: colors.textLow, cursor: "pointer", fontSize: 14 }}>✕</button>
        </RowBetween>
        <div style={{ flex: 1, overflowY: "auto", padding: "0 14px", display: "flex", flexDirection: "column", gap: 8 }}>
          {messages.map((m) => (
            <div key={m.id} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "80%", background: m.role === "user" ? colors.accent : colors.surface2, color: m.role === "user" ? colors.bg : colors.textHi, borderRadius: m.role === "user" ? "12px 12px 4px 12px" : "12px 12px 12px 4px", padding: "9px 12px", fontSize: 11, lineHeight: 1.4, border: m.role !== "user" ? `1px solid ${colors.border}` : "none" }}>{m.text}</div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6, padding: "8px 14px 16px" }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Savol yozing..." style={{ flex: 1, background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: "8px 10px", fontSize: 11, color: colors.textHi, fontFamily: fonts.body, outline: "none" }} />
          <button onClick={send} style={{ width: 30, height: 30, background: colors.accent, border: "none", borderRadius: 10, color: colors.bg, fontSize: 13, cursor: "pointer" }}>↑</button>
        </div>
      </div>
    </>
  );
}

/* ════════════════════════════════════════════════════════
   8. MOCK DATA (replace with API calls)
   ════════════════════════════════════════════════════════ */

const KPI_OWNER: KpiCardData[] = [
  { label: "RETENTION (30 KUN)", value: "73%", delta: "↑ 12% o'tgan oydan" },
  { label: "JAMI A'ZOLAR", value: "214", delta: "+18 yangi" },
  { label: "CHURN RISK", value: "9", delta: "↓ kuzatuv kerak", tone: "warn" },
  { label: "FAOL BUGUN", value: "87", delta: "41% DAU" },
];

const WEEKLY_ACTIVITY: TimeSeriesPoint[] = [
  { label: "Du", value: 58 }, { label: "Se", value: 72 }, { label: "Ch", value: 65 },
  { label: "Pa", value: 88 }, { label: "Ju", value: 80 }, { label: "Sh", value: 75 }, { label: "Ya", value: 70 },
];

const MEMBERS: Member[] = [
  { id: "1", initials: "JT", name: "Jasur Toshmatov", plan: "Pro", status: "active", streak: "🔥 14 kun", score: 2340, joinedAt: "12 fev, 2026" },
  { id: "2", initials: "NM", name: "Nilufar Mirzaeva", plan: "Starter", status: "active", streak: "🔥 7 kun", score: 1180, joinedAt: "3 mar, 2026" },
  { id: "3", initials: "DR", name: "Doniyor Raxmonov", plan: "Pro", status: "risk", streak: "0 kun", score: 340, joinedAt: "20 yan, 2026" },
  { id: "4", initials: "MA", name: "Mohira Aliyeva", plan: "Scale", status: "new", streak: "🌱 2 kun", score: 90, joinedAt: "24 iyun, 2026" },
  { id: "5", initials: "SQ", name: "Sevara Qodirova", plan: "Starter", status: "risk", streak: "0 kun", score: 210, joinedAt: "8 fev, 2026" },
  { id: "6", initials: "AB", name: "Aziz Boltayev", plan: "Pro", status: "risk", streak: "0 kun", score: 560, joinedAt: "15 yan, 2026" },
  { id: "7", initials: "BN", name: "Botir Niyozov", plan: "Pro", status: "active", streak: "🔥 21 kun", score: 1890, joinedAt: "2 dek, 2025" },
];

const BADGES: Badge[] = [
  { id: "1", icon: "✅", label: "Birinchi qadam", unlocked: true },
  { id: "2", icon: "🔥", label: "7 kunlik olov", unlocked: true },
  { id: "3", icon: "🗓️", label: "2 hafta jangchisi", unlocked: true },
  { id: "4", icon: "🛡️", label: "30 kunlik temir", unlocked: false, hint: "16 kun qoldi" },
  { id: "5", icon: "🤖", label: "AI do'sti", unlocked: true },
  { id: "6", icon: "🌅", label: "Tong qahramoni", unlocked: false, hint: "5tadan 2tasi" },
  { id: "7", icon: "⚖️", label: "Ozish ustasi", unlocked: true },
  { id: "8", icon: "🏆", label: "Reyting yulduzi", unlocked: false, hint: "Top-3, 4 hafta" },
];

const OWNER_INSIGHTS: AiInsight[] = [
  { id: "1", tone: "warn", title: "3 ta a'zo yuqori churn xavfida", body: "Birgalikda ehtimollik ~68%. Shaxsiy xabar yuborish tavsiya etiladi.", actionLabel: "Xabar tayyorlash →" },
  { id: "2", tone: "default", title: "Seshanba kunlari faollik eng past", body: "6 oy davomida Seshanba haftaning eng kam faol kuni.", actionLabel: "Eslatma sozlash →" },
  { id: "3", tone: "good", title: "Pro reja konversiyasi yaxshilanmoqda", body: "Starter'dan Pro'ga o'tish darajasi 6 oyda 14% dan 22% ga oshdi.", actionLabel: "To'liq tahlil →" },
];

const TRAINER_INSIGHTS: AiInsight[] = [
  { id: "1", tone: "warn", title: "Madina bilan bog'lanish kerak", body: "3 kun checkin yo'q + charchoq belgilari. Churn ehtimoli o'rtacha.", actionLabel: "Xabar tayyorlash →" },
  { id: "2", tone: "default", title: "Dilnozaning adherence pasaymoqda", body: "Oxirgi 2 haftada 65% dan 42% ga tushdi.", actionLabel: "Dasturni ko'rish →" },
];

const ADMIN_INSIGHTS: AiInsight[] = [
  { id: "1", tone: "warn", title: "PowerFit Samarqand'da AI sarfi anomal", body: "Bitta foydalanuvchi haddan tashqari ko'p so'rov yubormoqda.", actionLabel: "Hisobni tekshirish →" },
  { id: "2", tone: "default", title: "6 gym churn xavfida", body: "To'lov kechikishi + faollik pasayishi kombinatsiyasi aniqlandi.", actionLabel: "Ro'yxatni ko'rish →" },
];

/* ════════════════════════════════════════════════════════
   9. OWNER PAGES
   ════════════════════════════════════════════════════════ */

function OwnerDashboard({ onOpenMember, onNavigate }: { onOpenMember: (m: Member) => void; onNavigate: (id: string) => void }) {
  return (
    <>
      <RowBetween style={{ marginBottom: 22 }}>
        <div>
          <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Xush kelibsiz, Botir 👋</div>
          <div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>FitZone Gym · Yunusobod, Toshkent</div>
        </div>
        <div style={{ background: colors.accentDim, border: `1px solid ${colors.accentBorder}`, color: colors.accent, fontSize: 11, padding: "5px 12px", borderRadius: 999, fontFamily: fonts.mono }}>PRO TARIF</div>
      </RowBetween>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        {KPI_OWNER.map((k, i) => <KpiCard key={i} {...k} />)}
      </div>

      <InsightCard insight={{ ...OWNER_INSIGHTS[0], title: "🤖 " + OWNER_INSIGHTS[0].title, onAction: () => onNavigate("copilot") }} />

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, marginTop: 6 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel title="HAFTALIK FAOLLIK"><BarChart data={WEEKLY_ACTIVITY} /></Panel>
          <Panel title="SO'NGGI A'ZOLAR" action={<span onClick={() => onNavigate("members")}>Hammasi →</span>}>
            <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
              <thead><tr>{["A'ZO", "STREAK", "BALL", "HOLAT"].map((h) => <th key={h} style={{ textAlign: "left", color: colors.textDim, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, paddingBottom: 10, borderBottom: `1px solid ${colors.border}` }}>{h}</th>)}</tr></thead>
              <tbody>
                {MEMBERS.slice(0, 4).map((m) => (
                  <tr key={m.id} style={{ cursor: "pointer" }} onClick={() => onOpenMember(m)}>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar initials={m.initials} /><span style={{ color: colors.textHi }}>{m.name}</span></div></td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: m.streak === "0 kun" ? colors.bad : colors.textHi }}>{m.streak}</td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: colors.accent }}>{m.score}</td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><Pill label={m.status === "active" ? "Faol" : m.status === "risk" ? "Risk" : "Yangi"} tone={statusTone(m.status)} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel title="⚠️ CHURN OGOHLANTIRISH" action={<span onClick={() => onNavigate("members")}>Ko'rish →</span>}>
            {MEMBERS.filter((m) => m.status === "risk").map((m) => (
              <RiskRow key={m.id} onClick={() => onOpenMember(m)}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ width: 6, height: 6, borderRadius: "50%", background: colors.bad }} />{m.name}</div>
                <span style={{ fontFamily: fonts.mono, color: colors.bad, fontSize: 11 }}>{m.streak === "0 kun" ? "5+ kun yo'q" : m.streak}</span>
              </RiskRow>
            ))}
          </Panel>
          <Panel title="🏆 HAFTALIK TOP" action={<span onClick={() => onNavigate("challenge")}>Challenge →</span>}>
            {MEMBERS.filter((m) => m.status === "active").sort((a, b) => b.score - a.score).map((m, i) => (
              <RiskRow key={m.id}>
                <span style={{ color: i === 0 ? colors.accent : colors.textHi }}>{["🥇", "🥈", "🥉"][i] ?? `${i + 1}.`} {m.name}</span>
                <span style={{ fontFamily: fonts.mono, color: i === 0 ? colors.accent : colors.textDim }}>{m.score.toLocaleString()}</span>
              </RiskRow>
            ))}
          </Panel>
        </div>
      </div>
    </>
  );
}

function OwnerMembers({ onOpenMember }: { onOpenMember: (m: Member) => void }) {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? MEMBERS : MEMBERS.filter((m) => m.status === filter);
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>A'zolar</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>{MEMBERS.length} ta a'zo · {MEMBERS.filter((m) => m.status === "risk").length} tasi xavf ostida</div></div>
        <Button>+ A'zo qo'shish</Button>
      </RowBetween>
      <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
        {[{ id: "all", label: "Barchasi" }, { id: "active", label: "Faol" }, { id: "risk", label: "Risk" }, { id: "new", label: "Yangi" }].map((c) => (
          <div key={c.id} onClick={() => setFilter(c.id)} style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: 0.5, padding: "6px 12px", borderRadius: 999, cursor: "pointer", background: filter === c.id ? colors.accent : colors.surface2, color: filter === c.id ? colors.bg : colors.textLow, fontWeight: filter === c.id ? 600 : 400, border: `1px solid ${filter === c.id ? colors.accent : colors.border}` }}>{c.label}</div>
        ))}
      </div>
      <Panel>
        <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
          <thead><tr>{["A'ZO", "REJA", "STREAK", "BALL", "HOLAT", ""].map((h) => <th key={h} style={{ textAlign: "left", color: colors.textDim, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, paddingBottom: 10, borderBottom: `1px solid ${colors.border}` }}>{h}</th>)}</tr></thead>
          <tbody>
            {filtered.map((m) => (
              <tr key={m.id} style={{ cursor: "pointer" }} onClick={() => onOpenMember(m)}>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar initials={m.initials} /><span style={{ color: colors.textHi }}>{m.name}</span></div></td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, color: colors.textLow }}>{m.plan}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: m.streak === "0 kun" ? colors.bad : colors.textHi }}>{m.streak}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: colors.accent }}>{m.score}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><Pill label={m.status === "active" ? "Faol" : m.status === "risk" ? "Risk" : "Yangi"} tone={statusTone(m.status)} /></td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, color: colors.textDim }}>→</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

function MemberDetail({ member, onBack }: { member: Member; onBack: () => void }) {
  const risky = member.status === "risk";
  return (
    <>
      <span onClick={onBack} style={{ fontFamily: fonts.mono, fontSize: 11, color: colors.textLow, cursor: "pointer", marginBottom: 14, display: "inline-block" }}>← A'zolarga qaytish</span>
      <RowBetween style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <Avatar initials={member.initials} size="lg" />
          <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>{member.name}</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>{member.plan} reja · a'zo bo'lgan: {member.joinedAt}</div></div>
        </div>
        <div style={{ display: "flex", gap: 8 }}><Button variant="outline">📩 Xabar yuborish</Button><Button>📞 Qo'ng'iroq qilish</Button></div>
      </RowBetween>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <KpiCard label="STREAK" value={member.streak} />
        <KpiCard label="BALL" value={String(member.score)} />
        <KpiCard label="HOLAT" value={member.status === "risk" ? "Risk" : "Faol"} tone={risky ? "warn" : "default"} />
        <KpiCard label="DARAJA" value="👑 5 · Usta" />
      </div>
      {risky && (
        <InsightCard insight={{ id: "m", tone: "warn", title: "🤖 AI tahlili: churn ehtimoli yuqori (74%)", body: `${member.name} 8 kundan beri checkin qilmagan, oxirgi 2 haftada AI Trener bilan suhbat ham to'xtagan.`, actionLabel: "🤖 AI orqali shaxsiy xabar yubor →" }} />
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 6 }}>
        <Panel title="FAOLLIK TARIXI">
          {[["8 KUN OLDIN", "Oxirgi checkin — keyin faollik to'xtagan"], ["16 KUN OLDIN", "\"30 kunlik temir\" challenge'ga qo'shildi"], ["22 KUN OLDIN", "AI Trener bilan 4 marta suhbat"], [member.joinedAt, "Gym'ga a'zo bo'ldi"]].map(([d, t], i) => (
            <div key={i} style={{ display: "flex", gap: 10, padding: "10px 0", borderBottom: i < 3 ? `1px solid ${colors.surface3}` : "none", fontSize: 12 }}>
              <div style={{ width: 7, height: 7, borderRadius: "50%", background: colors.accent, marginTop: 4, flexShrink: 0 }} />
              <div><div style={{ color: colors.textDim, fontSize: 10, fontFamily: fonts.mono, marginBottom: 2 }}>{d}</div>{t}</div>
            </div>
          ))}
        </Panel>
        <Panel title="TO'LOV TARIXI">
          <RiskRow><span>14 iyun 2026</span><Pill label="To'landi" tone="good" /></RiskRow>
          <RiskRow><span>14 may 2026</span><Pill label="To'landi" tone="good" /></RiskRow>
          <RiskRow><span>14 apr 2026</span><Pill label="3 kun kechikkan" tone="mid" /></RiskRow>
          <Divider />
          <MonoLabel>YUTUQLAR</MonoLabel>
          <BadgeGrid badges={BADGES.slice(0, 4)} />
        </Panel>
      </div>
    </>
  );
}

function OwnerAnalytics() {
  const revenue: TimeSeriesPoint[] = [{ label: "Yan", value: 40 }, { label: "Fev", value: 52 }, { label: "Mar", value: 48 }, { label: "Apr", value: 60 }, { label: "May", value: 68 }, { label: "Iyun", value: 88 }];
  const growth: TimeSeriesPoint[] = [{ label: "Yan", value: 50 }, { label: "Fev", value: 55 }, { label: "Mar", value: 62 }, { label: "Apr", value: 70 }, { label: "May", value: 80 }, { label: "Iyun", value: 95 }];
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Analytics</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>FitZone Gym · Oxirgi 6 oy</div></div>
        <Button variant="outline">Export CSV</Button>
      </RowBetween>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <KpiCard label="MRR" value="$6,240" delta="↑ 9.3%" />
        <KpiCard label="O'RTACHA LTV" value="$184" delta="↑ 4.1%" />
        <KpiCard label="CHURN (OYLIK)" value="4.1%" delta="↑ 0.6%" tone="warn" />
        <KpiCard label="AI SARFI" value="$31" delta="Bu oy" />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Panel title="DAROMAD DINAMIKASI · 6 OY"><BarChart data={revenue} /></Panel>
        <Panel title="A'ZOLAR O'SISHI · 6 OY"><BarChart data={growth} /></Panel>
      </div>
      <Panel title="FAOLLIK TAQSIMOTI">
        {[["🏠 Bosh sahifa ochilishi", "38%"], ["💪 Plan bajarilishi", "27%"], ["🥗 Ovqat yozish", "21%"], ["🤖 AI Trener bilan suhbat", "14%"]].map(([l, v]) => (
          <RiskRow key={l}><span>{l}</span><span style={{ fontFamily: fonts.mono, color: colors.accent }}>{v}</span></RiskRow>
        ))}
      </Panel>
    </>
  );
}

function OwnerChallenge() {
  const [showForm, setShowForm] = useState(false);
  const streakDist: TimeSeriesPoint[] = [{ label: "0-3", value: 30 }, { label: "4-7", value: 55 }, { label: "8-14", value: 90 }, { label: "15-21", value: 45 }, { label: "22-29", value: 25 }, { label: "30+", value: 15 }];

  if (showForm) {
    return (
      <>
        <span onClick={() => setShowForm(false)} style={{ fontFamily: fonts.mono, fontSize: 11, color: colors.textLow, cursor: "pointer", marginBottom: 14, display: "inline-block" }}>← Challenge sahifasiga qaytish</span>
        <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 18 }}>Yangi challenge yaratish</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <Panel>
            <FormField label="CHALLENGE NOMI" defaultValue="🔥 30 kunlik yoz marafoni" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <FormField label="BOSHLANISH SANASI" defaultValue="1 iyul, 2026" />
              <FormSelect label="DAVOMIYLIGI" options={["30 kun", "14 kun", "7 kun"]} />
            </div>
            <FormSelect label="MAQSAD TURI" options={["Ketma-ket checkin (streak)", "Jami mashqlar soni", "AI Trener bilan suhbatlar"]} />
            <FormSelect label="AUDITORIYA" options={["Barcha a'zolar (214)", "Faqat Pro reja (96)", "Risk ostidagilar (9)"]} />
          </Panel>
          <Panel title="MUKOFOT">
            <div style={{ fontSize: 12, padding: "10px 12px", borderRadius: 10, background: colors.accentDim, border: `1px solid ${colors.accentBorder}`, marginBottom: 8 }}>🏅 Maxsus badge — &quot;Yoz jangchisi&quot;</div>
            <div style={{ fontSize: 12, padding: "10px 12px", borderRadius: 10, background: colors.surface2, border: `1px solid ${colors.border}`, marginBottom: 8 }}>🎟️ Keyingi oy uchun 20% chegirma</div>
            <div style={{ fontSize: 12, padding: "10px 12px", borderRadius: 10, background: colors.surface2, border: `1px solid ${colors.border}`, marginBottom: 8 }}>🎁 Gym sovg'a — protein/sherbet</div>
          </Panel>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
          <Button variant="outline" onClick={() => setShowForm(false)}>Bekor qilish</Button>
          <Button onClick={() => setShowForm(false)}>Challenge&apos;ni ishga tushirish</Button>
        </div>
      </>
    );
  }

  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Challenge & Gamifikatsiya</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>FitZone Gym · Joriy kampaniya</div></div>
        <Button onClick={() => setShowForm(true)}>+ Yangi challenge</Button>
      </RowBetween>
      <Panel style={{ marginBottom: 16 }}>
        <MonoLabel>JORIY CHALLENGE</MonoLabel>
        <RowBetween style={{ marginBottom: 10 }}>
          <div><div style={{ fontFamily: fonts.display, fontWeight: 600, fontSize: 15, color: colors.textHi }}>🔥 &quot;30 kunlik temir&quot; — Iyun marafoni</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>18 / 30 kun · 64 a&apos;zo ishtirok etmoqda</div></div>
          <Pill label="FAOL" tone="accent" />
        </RowBetween>
        <ProgressBar value={60} />
      </Panel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Panel title="🏆 UMUMIY REYTING — IYUN">
          {MEMBERS.filter((m) => m.status === "active").sort((a, b) => b.score - a.score).map((m, i) => (
            <RiskRow key={m.id}><span style={{ color: i === 0 ? colors.accent : colors.textHi }}>{["🥇", "🥈", "🥉"][i] ?? `${i + 1}.`} {m.name}</span><span style={{ fontFamily: fonts.mono, color: i === 0 ? colors.accent : colors.textDim }}>{m.score}</span></RiskRow>
          ))}
        </Panel>
        <Panel title="STREAK TAQSIMOTI">
          <StreakHistogram data={streakDist} />
          <div style={{ fontSize: 11, color: colors.textLow, marginTop: 10, lineHeight: 1.5 }}>Eng ko&apos;p a&apos;zo 8-14 kunlik streak guruhida — bu yerda tushib qolish xavfi yuqori.</div>
        </Panel>
      </div>
      <Panel title="GYM BO'YICHA BADGE TAQSIMOTI">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
          {[["✅", "Birinchi qadam", "214 / 214"], ["🔥", "7 kunlik olov", "158 / 214"], ["🗓️", "2 hafta jangchisi", "96 / 214"], ["🛡️", "30 kunlik temir", "41 / 214"]].map(([icon, label, n]) => (
            <div key={label} style={{ background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 12, padding: "14px 10px", textAlign: "center" }}>
              <div style={{ fontSize: 24, marginBottom: 6 }}>{icon}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: colors.textHi }}>{label}</div>
              <div style={{ fontSize: 10, color: colors.textDim, fontFamily: fonts.mono }}>{n}</div>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

function FormField({ label, defaultValue }: { label: string; defaultValue?: string }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, color: colors.textDim, marginBottom: 6 }}>{label}</div>
      <input defaultValue={defaultValue} style={{ width: "100%", background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 9, padding: "10px 12px", fontSize: 12, color: colors.textHi, fontFamily: fonts.body }} />
    </div>
  );
}
function FormSelect({ label, options }: { label: string; options: string[] }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, color: colors.textDim, marginBottom: 6 }}>{label}</div>
      <select style={{ width: "100%", background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 9, padding: "10px 12px", fontSize: 12, color: colors.textHi, fontFamily: fonts.body }}>
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function OwnerMessages() {
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Xabar yuborish</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>FitZone Gym · Ommaviy xabarlar</div></div>
        <Button>Yangi kampaniya</Button>
      </RowBetween>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Panel title="XABAR YOZISH">
          <div style={{ background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: 14, fontSize: 12, color: colors.textLow, minHeight: 90, lineHeight: 1.6 }}>
            &quot;Salom! Bu hafta 30 kunlik challenge yarmiga yetdik 🔥 Hozir to&apos;xtab qolmang.&quot;
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}><Button variant="outline">🤖 AI bilan yozish</Button><Button style={{ marginLeft: "auto" }}>Yuborish (64 ta a&apos;zo)</Button></div>
        </Panel>
        <Panel title="AUDITORIYA">
          {[["🔥 Challenge ishtirokchilari", 64, true], ["⚠️ Risk ostidagilar", 9, false], ["🌱 Yangi a'zolar (7 kun)", 18, false], ["👥 Barcha a'zolar", 214, false]].map(([l, n, sel]: any) => (
            <div key={l} style={{ background: sel ? colors.accentDim : colors.surface2, border: `1px solid ${sel ? colors.accentBorder : colors.border}`, borderRadius: 10, padding: "12px 14px", display: "flex", justifyContent: "space-between", marginBottom: 8, cursor: "pointer" }}>
              <span style={{ fontSize: 12 }}>{l}</span><span style={{ fontFamily: fonts.mono, color: sel ? colors.accent : colors.textLow }}>{n}</span>
            </div>
          ))}
        </Panel>
      </div>
      <Panel title="YUBORILGAN KAMPANIYALAR">
        <RiskRow><div><div style={{ fontWeight: 500 }}>Challenge yarim yo&apos;l eslatmasi</div><div style={{ fontSize: 10, color: colors.textDim }}>14 iyun, 09:00 · 64 qabul qiluvchi</div></div><Pill label="96% o'qilgan" tone="good" /></RiskRow>
        <RiskRow><div><div style={{ fontWeight: 500 }}>Risk ostidagilarga shaxsiy xabar</div><div style={{ fontSize: 10, color: colors.textDim }}>10 iyun, 18:00 · 9 qabul qiluvchi</div></div><Pill label="67% o'qilgan" tone="mid" /></RiskRow>
      </Panel>
    </>
  );
}

function OwnerSettings() {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 20 }}>Sozlamalar</div>
      <Panel style={{ marginBottom: 16 }}><MonoLabel>GYM PROFILI</MonoLabel>
        <SettingsRow label="Gym nomi" desc="FitZone Gym" />
        <SettingsRow label="Manzil" desc="Yunusobod, Toshkent" last />
      </Panel>
      <Panel style={{ marginBottom: 16 }}><MonoLabel>BILDIRISHNOMALAR</MonoLabel>
        <SettingsRow label="Churn ogohlantirishlari" desc="AI 5+ kun faol bo'lmaganda" toggle defaultOn />
        <SettingsRow label="Haftalik hisobot" desc="Har Yakshanba email orqali" toggle defaultOn last />
      </Panel>
      <Panel><MonoLabel>BILLING</MonoLabel>
        <SettingsRow label="Joriy reja" desc="Pro · $69/oy · keyingi to'lov 14 iyul" action="Rejani o'zgartirish" last />
      </Panel>
    </>
  );
}

function SettingsRow({ label, desc, toggle, defaultOn, action, last }: { label: string; desc: string; toggle?: boolean; defaultOn?: boolean; action?: string; last?: boolean }) {
  const [on, setOn] = useState(!!defaultOn);
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 0", borderBottom: last ? "none" : `1px solid ${colors.surface3}` }}>
      <div><div style={{ fontSize: 13, fontWeight: 500, color: colors.textHi }}>{label}</div><div style={{ fontSize: 11, color: colors.textDim, marginTop: 2 }}>{desc}</div></div>
      {toggle ? (
        <div onClick={() => setOn(!on)} style={{ width: 36, height: 20, borderRadius: 20, background: on ? colors.accent : colors.surface3, position: "relative", cursor: "pointer", flexShrink: 0 }}>
          <div style={{ width: 16, height: 16, borderRadius: "50%", background: on ? colors.bg : colors.textHi, position: "absolute", top: 2, left: on ? 18 : 2, transition: "left .15s ease" }} />
        </div>
      ) : action ? <Button variant="primary" size="sm">{action}</Button> : <Button variant="outline" size="sm">Tahrirlash</Button>}
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   10. TRAINER PAGES
   ════════════════════════════════════════════════════════ */

const CLIENTS: Member[] = [
  { id: "c1", initials: "JT", name: "Jasur Tashkentov", plan: "Pro", status: "active", streak: "", score: 0, adherence: 81, joinedAt: "" },
  { id: "c2", initials: "DK", name: "Dilnoza Karimova", plan: "Starter", status: "risk", streak: "", score: 0, adherence: 42, joinedAt: "" },
  { id: "c3", initials: "OR", name: "Otabek Rashidov", plan: "Pro", status: "active", streak: "", score: 0, adherence: 88, joinedAt: "" },
  { id: "c4", initials: "MY", name: "Madina Yusupova", plan: "Starter", status: "risk", streak: "", score: 0, adherence: 30, joinedAt: "" },
];

function TrainerToday({ onNavigate }: { onNavigate: (id: string) => void }) {
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Bugun, Coach Aziz 👋</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>Dushanba · 6 seans, 2 ta qoldi</div></div>
        <Button variant="outline">+ Seans qo&apos;shish</Button>
      </RowBetween>
      <InsightCard insight={{ id: "t", tone: "warn", title: "🤖 AI Copilot: Madina bilan bog'lanish vaqti keldi", body: "3 kundan beri checkin yo'q, oxirgi seansda charchoq belgilari bor edi.", actionLabel: "Copilot bilan xabar tayyorlash →", onAction: () => onNavigate("copilot") }} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 6 }}>
        <Panel title="BUGUNGI SEANSLAR">
          <RiskRow><span>14:00 · Jasur Tashkentov — Kuch mashqi</span><Pill label="Tayyor" tone="good" /></RiskRow>
          <RiskRow><span>15:30 · Madina Yusupova — Cardio</span><Pill label="3 kun yo'q" tone="bad" /></RiskRow>
          <RiskRow><span>17:00 · Otabek Rashidov — Yelka</span><Pill label="Tayyor" tone="good" /></RiskRow>
        </Panel>
        <Panel title="BU OYDAGI NATIJA">
          <div style={{ marginBottom: 10 }}><KpiCard label="FAOL MIJOZLAR" value="22" /></div>
          <KpiCard label="O'RTACHA ADHERENCE" value="81%" />
        </Panel>
      </div>
    </>
  );
}

function TrainerClients({ onOpenMember }: { onOpenMember: (m: Member) => void }) {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 4 }}>Mijozlarim</div>
      <div style={{ color: colors.textDim, fontSize: 12, marginBottom: 20 }}>22 ta faol mijoz</div>
      <Panel>
        <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
          <thead><tr>{["MIJOZ", "ADHERENCE", "HOLAT", ""].map((h) => <th key={h} style={{ textAlign: "left", color: colors.textDim, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, paddingBottom: 10, borderBottom: `1px solid ${colors.border}` }}>{h}</th>)}</tr></thead>
          <tbody>
            {CLIENTS.map((c) => (
              <tr key={c.id} style={{ cursor: "pointer" }} onClick={() => onOpenMember(c)}>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar initials={c.initials} /><span style={{ color: colors.textHi }}>{c.name}</span></div></td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: (c.adherence ?? 0) < 50 ? colors.bad : colors.accent }}>{c.adherence}%</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><Pill label={c.status === "active" ? "Faol" : "Risk"} tone={statusTone(c.status)} /></td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, color: colors.textDim }}>→</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

function TrainerSchedule() {
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Jadval</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>Bu hafta</div></div>
        <Button variant="outline">+ Bo&apos;sh vaqt qo&apos;shish</Button>
      </RowBetween>
      <Panel>
        {[["Dushanba", 6, false], ["Seshanba", 8, true], ["Chorshanba", 5, false], ["Payshanba", 7, false]].map(([d, n, hi]: any) => (
          <RiskRow key={d}><span style={{ color: hi ? colors.accent : colors.textHi }}>{d}</span><span style={{ fontFamily: fonts.mono, color: hi ? colors.accent : colors.textLow }}>{n} seans</span></RiskRow>
        ))}
      </Panel>
    </>
  );
}

function TrainerAnalytics() {
  const adherence: TimeSeriesPoint[] = [{ label: "Yan", value: 55 }, { label: "Fev", value: 60 }, { label: "Mar", value: 58 }, { label: "Apr", value: 65 }, { label: "May", value: 75 }, { label: "Iyun", value: 81 }];
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 4 }}>Analytics</div>
      <div style={{ color: colors.textDim, fontSize: 12, marginBottom: 20 }}>Mijozlarim bo&apos;yicha chuqur tahlil</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <KpiCard label="JAMI SEANSLAR (OY)" value="96" delta="↑ 8%" />
        <KpiCard label="O'RTACHA ADHERENCE" value="81%" delta="↑ 13%" />
        <KpiCard label="RISK MIJOZLAR" value="2" tone="warn" />
        <KpiCard label="BU OY DAROMAD" value="$1,840" delta="↑ 7%" />
      </div>
      <Panel title="MIJOZLAR ADHERENCE · 6 OY" style={{ marginBottom: 16 }}><BarChart data={adherence} /></Panel>
      <Panel title="MIJOZ BO'YICHA TAQSIMOT">
        {CLIENTS.map((c) => <RiskRow key={c.id}><span>{c.name}</span><span style={{ fontFamily: fonts.mono, color: (c.adherence ?? 0) < 50 ? colors.bad : colors.accent }}>{c.adherence}%</span></RiskRow>)}
      </Panel>
    </>
  );
}

function TrainerSettings() {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 20 }}>Sozlamalar</div>
      <Panel style={{ marginBottom: 16 }}>
        <SettingsRow label="Ism" desc="Coach Aziz" />
        <SettingsRow label="Mutaxassislik" desc="Kuch mashqlari" last />
      </Panel>
      <Panel><SettingsRow label="Risk mijoz ogohlantirishi" desc="3+ kun checkin bo'lmaganda" toggle defaultOn last /></Panel>
    </>
  );
}

/* ════════════════════════════════════════════════════════
   11. SUPERADMIN PAGES
   ════════════════════════════════════════════════════════ */

const GYMS = [
  { i: "FZ", n: "FitZone Gym", city: "Toshkent", plan: "Pro", members: 214, status: "active" as const },
  { i: "PS", n: "PowerFit Samarqand", city: "Samarqand", plan: "Scale", members: 340, status: "risk" as const },
  { i: "IM", n: "IronMuscle", city: "Buxoro", plan: "Starter", members: 58, status: "active" as const },
  { i: "AG", n: "Atlant Gym", city: "Andijon", plan: "Pro", members: 126, status: "new" as const },
];

function AdminOverview({ onNavigate }: { onNavigate: (id: string) => void }) {
  const mrr: TimeSeriesPoint[] = [{ label: "Noy", value: 40 }, { label: "Dek", value: 48 }, { label: "Yan", value: 55 }, { label: "Fev", value: 60 }, { label: "Mar", value: 68 }, { label: "Apr", value: 75 }, { label: "May", value: 85 }, { label: "Iyun", value: 95 }];
  const signups: TimeSeriesPoint[] = [{ label: "Yan", value: 50 }, { label: "Fev", value: 62 }, { label: "Mar", value: 55 }, { label: "Apr", value: 80 }, { label: "May", value: 70 }, { label: "Iyun", value: 65 }];
  return (
    <>
      <RowBetween style={{ marginBottom: 20 }}>
        <div><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>Platforma umumiy ko&apos;rinishi</div><div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>VitaForge AI · barcha gym&apos;lar</div></div>
        <Button variant="outline">Export hisobot</Button>
      </RowBetween>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <KpiCard label="JAMI GYM" value="412" delta="↑ 8.2%" />
        <KpiCard label="MRR" value="$18,420" delta="↑ 12.5%" />
        <KpiCard label="CLAUDE API SARFI" value="$1,240" delta="↑ 4.5%" />
        <KpiCard label="CHURNED GYM" value="6" delta="↓ Oxirgi 30 kun" tone="warn" />
      </div>
      <InsightCard insight={{ id: "a", tone: "warn", title: "🤖 AI Copilot: bitta gym AI sarfi anomal o'sgan", body: "\"PowerFit Samarqand\" — bu hafta AI chaqiruvlari 3.2x oshgan, a'zolar soni o'zgarmagan.", actionLabel: "Copilot'da tekshirish →", onAction: () => onNavigate("copilot") }} />
      <Panel title="MRR O'SISHI · 8 OY" style={{ marginBottom: 16, marginTop: 6 }}><BarChart data={mrr} /></Panel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Panel title="YANGI SIGNUPLAR"><BarChart data={signups} /></Panel>
        <Panel title="TIZIM UPTIME"><div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 32, color: colors.textHi, margin: "18px 0" }}>99.94%</div><div style={{ fontFamily: fonts.mono, fontSize: 11, color: colors.good }}>Oxirgi 30 kun</div></Panel>
      </div>
    </>
  );
}

function AdminGyms() {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 4 }}>Zallar</div>
      <div style={{ color: colors.textDim, fontSize: 12, marginBottom: 20 }}>412 ta gym · 6 tasi churn xavfida</div>
      <Panel>
        <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
          <thead><tr>{["GYM", "SHAHAR", "REJA", "A'ZOLAR", "HOLAT"].map((h) => <th key={h} style={{ textAlign: "left", color: colors.textDim, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, paddingBottom: 10, borderBottom: `1px solid ${colors.border}` }}>{h}</th>)}</tr></thead>
          <tbody>
            {GYMS.map((g) => (
              <tr key={g.i}>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar initials={g.i} /><span style={{ color: colors.textHi }}>{g.n}</span></div></td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, color: colors.textLow }}>{g.city}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, color: colors.textLow }}>{g.plan}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono }}>{g.members}</td>
                <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}><Pill label={g.status === "active" ? "Faol" : g.status === "risk" ? "Risk" : "Yangi"} tone={statusTone(g.status)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}

function AdminBilling() {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 20 }}>Billing</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <KpiCard label="STARTER" value="186" /><KpiCard label="PRO" value="158" /><KpiCard label="SCALE" value="58" /><KpiCard label="ENTERPRISE" value="10" />
      </div>
      <Panel title="SO'NGGI TO'LOVLAR">
        <RiskRow><span>FitZone Gym — Pro</span><Pill label="$69 · to'landi" tone="good" /></RiskRow>
        <RiskRow><span>PowerFit Samarqand — Scale</span><Pill label="$149 · to'landi" tone="good" /></RiskRow>
        <RiskRow><span>IronMuscle — Starter</span><Pill label="$39 · muvaffaqiyatsiz" tone="bad" /></RiskRow>
      </Panel>
    </>
  );
}

function AdminAiUsage() {
  const daily: TimeSeriesPoint[] = [{ label: "Du", value: 45 }, { label: "Se", value: 55 }, { label: "Ch", value: 50 }, { label: "Pa", value: 65 }, { label: "Ju", value: 92 }, { label: "Sh", value: 60 }, { label: "Ya", value: 58 }];
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 20 }}>AI Usage</div>
      <Panel title="KUNLIK AI CHAQIRUVLARI" style={{ marginBottom: 16 }}><BarChart data={daily} /></Panel>
      <Panel title="GYM BO'YICHA SARF (BU OY)">
        <RiskRow><span style={{ color: colors.bad }}>⚠️ PowerFit Samarqand</span><span style={{ fontFamily: fonts.mono, color: colors.bad }}>$210</span></RiskRow>
        <RiskRow><span>FitZone Gym</span><span style={{ fontFamily: fonts.mono, color: colors.textLow }}>$31</span></RiskRow>
        <RiskRow><span>Atlant Gym</span><span style={{ fontFamily: fonts.mono, color: colors.textLow }}>$18</span></RiskRow>
      </Panel>
    </>
  );
}

function AdminSettings() {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 20 }}>Sozlamalar</div>
      <Panel>
        <SettingsRow label="Gym AI limit ogohlantirishi" desc="Kunlik $50 dan oshganda" toggle defaultOn />
        <SettingsRow label="Yangi gym moderatsiyasi" desc="Ro'yxatdan o'tishni qo'lda tasdiqlash" toggle last />
      </Panel>
    </>
  );
}

/* ════════════════════════════════════════════════════════
   12. MEMBER MOBILE PAGES
   ════════════════════════════════════════════════════════ */

function MemberHome({ onOpenAi }: { onOpenAi: () => void }) {
  const [checkedIn, setCheckedIn] = useState(false);
  return (
    <>
      <MonoLabel>XUSH KELIBSIZ</MonoLabel>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 17, color: colors.textHi, marginBottom: 10 }}>Salom, Jasur 👋</div>
      <MobileCard accent style={{ textAlign: "center", padding: 16 }}>
        {checkedIn ? (
          <div style={{ fontSize: 12, color: colors.textMid }}>✅ Bugun checkin qildingiz. Davom eting! 🔥</div>
        ) : (
          <>
            <div style={{ fontSize: 11, color: colors.accent, marginBottom: 6, fontFamily: fonts.mono }}>BUGUN HALI CHECKIN QILMADINGIZ</div>
            <BigButton onClick={() => setCheckedIn(true)}>📍 Gym ga keldim</BigButton>
          </>
        )}
      </MobileCard>
      <MobileCard>
        <RowBetween style={{ marginBottom: 8 }}>
          <span style={{ fontFamily: fonts.mono, fontSize: 8, letterSpacing: 1, color: colors.textDim }}>BUGUNGI KALORIYA</span>
          <span style={{ fontFamily: fonts.mono, fontSize: 11 }}><b style={{ color: colors.accent }}>340</b><span style={{ color: colors.textDim }}> / 1840</span></span>
        </RowBetween>
        <ProgressBar value={18} />
      </MobileCard>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 }}>
        {[["🥗", "Ovqat qo'shish"], ["📸", "Foto yuklash"]].map(([icon, label]) => (
          <div key={label} style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 12, padding: "12px 10px", display: "flex", flexDirection: "column", alignItems: "center", gap: 5, cursor: "pointer" }}>
            <span style={{ fontSize: 18 }}>{icon}</span><span style={{ fontSize: 10, color: colors.textMid, textAlign: "center" }}>{label}</span>
          </div>
        ))}
      </div>
      <MobileCard style={{ borderLeft: `2px solid ${colors.accent}`, cursor: "pointer" }} onClick={onOpenAi}>
        <div style={{ fontFamily: fonts.mono, fontSize: 9, color: colors.accent, letterSpacing: 1, marginBottom: 4 }}>🤖 AI TAVSIYASI</div>
        <div style={{ fontSize: 11, color: colors.textMid, lineHeight: 1.55 }}>Kecha protein normangizdan 22g kam yedingiz. Bugun tushlikka tuxum yoki tovuq qo&apos;shing.</div>
      </MobileCard>
    </>
  );
}

function MemberPlan() {
  return (
    <>
      <RowBetween style={{ padding: "4px 0 8px" }}><MonoLabel>3-HAFTA PLANI</MonoLabel><span style={{ fontSize: 11, color: colors.accent }}>🔄</span></RowBetween>
      <MobileCard accent>
        <div style={{ fontSize: 10, color: colors.accent, fontFamily: fonts.mono, marginBottom: 4 }}>BUGUN · DUSHANBA</div>
        <div style={{ fontWeight: 600, fontSize: 13, color: colors.textHi }}>💪 Kuch mashqi</div>
        <div style={{ fontSize: 10, color: colors.textLow }}>45 daqiqa · 6 mashq</div>
      </MobileCard>
      {[["Squat", "60s", "4×12"], ["Bench press", "90s", "4×10"], ["Deadlift", "90s", "3×8"]].map(([name, rest, sets], i) => (
        <MobileCard key={name} style={{ opacity: i === 2 ? 0.5 : 1 }}>
          <RowBetween>
            <div><div style={{ fontSize: 12, fontWeight: 500, color: colors.textHi }}>{name}</div><div style={{ fontSize: 10, color: colors.textDim }}>Dam: {rest}</div></div>
            <span style={{ fontFamily: fonts.mono, fontSize: 12, color: i === 2 ? colors.textHi : colors.accent }}>{sets}</span>
          </RowBetween>
        </MobileCard>
      ))}
      <BigButton>✓ Mashqni tugatdim</BigButton>
    </>
  );
}

function MemberFood() {
  return (
    <>
      <MonoLabel>OVQAT QO&apos;SHISH</MonoLabel>
      <MobileCard accent>
        <div style={{ fontSize: 10, color: colors.accent, fontFamily: fonts.mono, marginBottom: 8 }}>🤖 NIMA YEDINGIZ?</div>
        <div style={{ background: colors.surface2, border: `1px solid ${colors.border2}`, borderRadius: 10, padding: "10px 12px", fontSize: 12, color: colors.textLow }}>&quot;bir piyola osh va salat&quot;</div>
      </MobileCard>
      <MobileCard style={{ borderColor: colors.accentBorder }}>
        <RowBetween><span style={{ fontSize: 13, fontWeight: 600, color: colors.textHi }}>O&apos;zbek oshi</span><span style={{ fontFamily: fonts.mono, fontSize: 12, color: colors.accent }}>540 kcal</span></RowBetween>
      </MobileCard>
      <MobileCard><RowBetween><span style={{ fontSize: 13, fontWeight: 600, color: colors.textHi }}>Ko&apos;k salat</span><span style={{ fontFamily: fonts.mono, fontSize: 12, color: colors.accent }}>45 kcal</span></RowBetween></MobileCard>
      <BigButton>+ Qo&apos;shish (585 kcal)</BigButton>
    </>
  );
}

function MemberLeaderboard() {
  const board = [{ rank: "🥇", name: "Nilufar M.", score: 3120 }, { rank: "🥈", name: "Kamola S.", score: 2890 }, { rank: "🥉", name: "Siz", score: 2340, me: true }];
  return (
    <>
      <MonoLabel>HAFTALIK REYTING</MonoLabel>
      <MobileCard accent><div style={{ display: "flex", alignItems: "center", gap: 10 }}><Avatar initials="#3" /><div><div style={{ fontSize: 12, fontWeight: 600, color: colors.textHi }}>Siz</div><div style={{ fontSize: 10, color: colors.textLow }}>2,340 ball</div></div></div></MobileCard>
      {board.map((b) => (
        <MobileCard key={b.name}><div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 16 }}>{b.rank}</span><Avatar initials={b.name.slice(0, 2).toUpperCase()} />
          <div style={{ flex: 1, fontSize: 12, fontWeight: b.me ? 600 : 400, color: colors.textHi }}>{b.name}</div>
          <span style={{ fontFamily: fonts.mono, fontSize: 11, color: b.me ? colors.accent : colors.textDim }}>{b.score}</span>
        </div></MobileCard>
      ))}
    </>
  );
}

function MemberProfile({ onLogout }: { onLogout?: () => void }) {
  const [tab, setTab] = useState("main");
  const streak: StreakData = { current: 15, longest: 21, label: "kunlik streak", week: [true, true, true, false, true, true, true] };
  const level: Level = { num: 5, title: "Usta", icon: "👑", xp: 2340, xpMin: 1500, xpMax: 2500 };

  return (
    <>
      <MobileCard accent style={{ textAlign: "center", padding: 18 }}>
        <Avatar initials="JT" size="lg" />
        <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 14, color: colors.textHi, marginTop: 8 }}>Jasur Tashkentov</div>
        <div style={{ fontSize: 10, color: colors.textLow, marginTop: 2 }}>Pro reja · Powerhouse Gym</div>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 4, marginTop: 8, background: colors.accentDim, padding: "4px 10px", borderRadius: 999 }}>
          <span style={{ fontSize: 11 }}>{level.icon}</span><span style={{ fontSize: 10, color: colors.accent, fontFamily: fonts.mono }}>DARAJA {level.num} · {level.title}</span>
        </div>
      </MobileCard>
      <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
        {[["main", "UMUMIY"], ["pay", "TO'LOVLAR"], ["stats", "ANALITIKA"], ["alerts", "BILDIRISHNOMA"]].map(([id, label]) => (
          <div key={id} onClick={() => setTab(id)} style={{ fontFamily: fonts.mono, fontSize: 9, letterSpacing: 1, padding: "7px 12px", borderRadius: 999, cursor: "pointer", background: tab === id ? colors.accent : colors.surface2, color: tab === id ? colors.bg : colors.textLow, border: `1px solid ${tab === id ? colors.accent : colors.border}` }}>{label}</div>
        ))}
      </div>
      {tab === "main" && (
        <>
          <StreakCard data={streak} />
          <LevelBar level={level} />
          <MonoLabel>YUTUQLAR</MonoLabel>
          <BadgeGrid badges={BADGES} />
          <OutlineButton>Profilni tahrirlash</OutlineButton>
          {onLogout && (
            <div
              onClick={onLogout}
              style={{ textAlign: "center", padding: "12px 0 4px", fontSize: 12, color: colors.bad, cursor: "pointer" }}
            >
              🚪 Chiqish
            </div>
          )}
        </>
      )}
      {tab === "pay" && (
        <>
          <MobileCard accent><RowBetween><div><div style={{ fontSize: 12, fontWeight: 600, color: colors.textHi }}>Pro reja</div><div style={{ fontSize: 10, color: colors.textLow }}>Oylik obuna</div></div><span style={{ fontFamily: fonts.mono, fontSize: 13, color: colors.accent }}>$69/oy</span></RowBetween></MobileCard>
          <MonoLabel>TO&apos;LOV TARIXI</MonoLabel>
          {["14 iyun 2026", "14 may 2026", "14 apr 2026"].map((d) => <MobileCard key={d}><RowBetween><span style={{ fontSize: 11, color: colors.textHi }}>{d}</span><Pill label="To'landi" tone="good" /></RowBetween></MobileCard>)}
        </>
      )}
      {tab === "stats" && (
        <>
          <MonoLabel>VAZN DINAMIKASI · 6 OY</MonoLabel>
          <BarChart data={[{ label: "Yan", value: 58 }, { label: "Fev", value: 55 }, { label: "Mar", value: 52 }, { label: "Apr", value: 50 }, { label: "May", value: 48 }, { label: "Iyun", value: 46 }]} height={70} />
          <MobileCard accent style={{ marginTop: 8 }}><div style={{ fontSize: 11, color: colors.textMid, lineHeight: 1.55 }}>📉 6 oyda <b style={{ color: colors.accent }}>-7.2 kg</b>. Maqsadgacha 3.8 kg qoldi.</div></MobileCard>
        </>
      )}
      {tab === "alerts" && (
        <>
          <MobileCard accent><div style={{ fontSize: 11, color: colors.accent, fontFamily: fonts.mono, marginBottom: 3 }}>BUGUN</div><div style={{ fontSize: 12, color: colors.textHi }}>🔥 15-kun streak! Top 10%dasiz.</div></MobileCard>
          <MobileCard><div style={{ fontSize: 11, color: colors.textDim, fontFamily: fonts.mono, marginBottom: 3 }}>KECHA</div><div style={{ fontSize: 12, color: colors.textHi }}>🤖 AI: Protein normangizga 18g qoldi.</div></MobileCard>
        </>
      )}
    </>
  );
}

/* ════════════════════════════════════════════════════════
   13. AI COPILOT PAGE (wraps AiCopilot for a role)
   ════════════════════════════════════════════════════════ */

function CopilotPage({ role }: { role: AppRole }) {
  const configs: Record<string, { messages: ChatMessage[]; insights: AiInsight[] }> = {
    owner: {
      messages: [
        { id: "1", role: "ai", text: "Salom Botir! Bugun e'tibor talab qiladigan 3 ta narsa bor." },
        { id: "2", role: "user", text: "Ha, boshla" },
        { id: "3", role: "ai", text: "Doniyor, Sevara va Aziz — uchalasi ham 5+ kun checkin qilmagan. Shaxsiy xabar yuborishimni xohlaysizmi?" },
      ],
      insights: OWNER_INSIGHTS,
    },
    trainer: {
      messages: [
        { id: "1", role: "ai", text: "Salom Coach! Madina haqida xabar bermoqchiman — 3 kun checkin yo'q." },
        { id: "2", role: "user", text: "Nima tavsiya qilasan?" },
        { id: "3", role: "ai", text: "Avval shaxsiy holini so'rab, agar charchagan bo'lsa — 1 kunlik dam olish taklif qiling." },
      ],
      insights: TRAINER_INSIGHTS,
    },
    superadmin: {
      messages: [
        { id: "1", role: "ai", text: "Salom! PowerFit Samarqand'da AI sarfi anomal o'sgan — ko'rib chiqaymi?" },
        { id: "2", role: "user", text: "Ha, sabab nima?" },
        { id: "3", role: "ai", text: "Bitta foydalanuvchi soatiga 40+ marta murojaat qilgan. Hisobni cheklashni tavsiya qilaman." },
      ],
      insights: ADMIN_INSIGHTS,
    },
  };
  const cfg = configs[role] ?? configs.owner;
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi, marginBottom: 4 }}>🤖 AI Copilot</div>
      <div style={{ color: colors.textDim, fontSize: 12, marginBottom: 20 }}>Erkin so&apos;rang yoki proaktiv tavsiyalarni ko&apos;rib chiqing</div>
      <AiCopilot role={role} initialMessages={cfg.messages} insights={cfg.insights} />
    </>
  );
}

/* ════════════════════════════════════════════════════════
   14. TOP-LEVEL APP — role switch + routing
   ════════════════════════════════════════════════════════ */

interface VitaForgeAppProps {
  /** Role the logged-in session started as (from /login). Determines whether Super Admin can be reached via the in-app switcher. */
  initialRole?: AppRole;
  /** Display name/email shown in sidebar + mobile profile. */
  userName?: string;
  userEmail?: string;
  /** Called when the person clicks "Chiqish" (Logout). */
  onLogout?: () => void;
}

export function VitaForgeApp({ initialRole = "owner", userName, userEmail, onLogout }: VitaForgeAppProps) {
  const [role, setRole] = useState<AppRole>(initialRole);
  const [desktopPage, setDesktopPage] = useState<Record<"owner" | "trainer" | "superadmin", string>>({ owner: "dashboard", trainer: "today", superadmin: "overview" });
  const [mobilePage, setMobilePage] = useState("home");
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [aiSheetOpen, setAiSheetOpen] = useState(false);

  // Only a session that actually logged in as Super Admin (via gated
  // email/password) can switch INTO the Super Admin view from the picker.
  // Demo Owner/Trainer/Member sessions can freely explore each other.
  const canReachSuperAdmin = initialRole === "superadmin";

  const switchRole = (r: AppRole) => { setRole(r); setSelectedMember(null); };

  if (role === "member") {
    const pages: Record<string, React.ReactNode> = {
      home: <MemberHome onOpenAi={() => setAiSheetOpen(true)} />,
      plan: <MemberPlan />,
      food: <MemberFood />,
      top: <MemberLeaderboard />,
      profile: <MemberProfile onLogout={onLogout} />,
    };
    return (
      <>
        <GlobalStyles />
        <RolePicker role={role} onSwitch={switchRole} allowSuperAdmin={canReachSuperAdmin} />
        <div style={{ display: "flex", flexDirection: "column", height: 680, background: colors.bg, maxWidth: 380, margin: "0 auto", borderRadius: 24, overflow: "hidden", border: `1px solid ${colors.border}` }}>
          <div style={{ height: 30, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 18px", fontSize: 10, color: colors.textMid, fontFamily: fonts.mono, flexShrink: 0 }}><span>9:41</span><span>●●●●</span></div>
          <MobileTopBar onAction={() => setAiSheetOpen(true)} />
          <div style={{ flex: 1, overflowY: "auto", padding: "0 14px", display: "flex", flexDirection: "column" }}>{pages[mobilePage]}</div>
          <MobileBottomNav page={mobilePage} onNavigate={setMobilePage} />
        </div>
        <AiChatSheet open={aiSheetOpen} onClose={() => setAiSheetOpen(false)} role={role} />
      </>
    );
  }

  const currentPage = desktopPage[role];
  const setPage = (id: string) => { setDesktopPage((p) => ({ ...p, [role]: id })); setSelectedMember(null); };

  const ownerPages: Record<string, React.ReactNode> = {
    dashboard: <OwnerDashboard onOpenMember={setSelectedMember} onNavigate={setPage} />,
    members: selectedMember ? <MemberDetail member={selectedMember} onBack={() => setSelectedMember(null)} /> : <OwnerMembers onOpenMember={setSelectedMember} />,
    analytics: <OwnerAnalytics />,
    challenge: <OwnerChallenge />,
    copilot: <CopilotPage role="owner" />,
    messages: <OwnerMessages />,
    settings: <OwnerSettings />,
  };
  const trainerPages: Record<string, React.ReactNode> = {
    today: <TrainerToday onNavigate={setPage} />,
    clients: selectedMember ? <MemberDetail member={selectedMember} onBack={() => setSelectedMember(null)} /> : <TrainerClients onOpenMember={setSelectedMember} />,
    schedule: <TrainerSchedule />,
    analytics: <TrainerAnalytics />,
    copilot: <CopilotPage role="trainer" />,
    settings: <TrainerSettings />,
  };
  const adminPages: Record<string, React.ReactNode> = {
    overview: <AdminOverview onNavigate={setPage} />,
    gyms: <AdminGyms />,
    billing: <AdminBilling />,
    aiusage: <AdminAiUsage />,
    copilot: <CopilotPage role="superadmin" />,
    settings: <AdminSettings />,
  };
  const pageMap = role === "owner" ? ownerPages : role === "trainer" ? trainerPages : adminPages;
  const userLabel = userName && userEmail ? `${userName} · ${userEmail}` : userEmail;

  return (
    <>
      <GlobalStyles />
      <RolePicker role={role} onSwitch={switchRole} allowSuperAdmin={canReachSuperAdmin} />
      <div style={{ display: "flex", minHeight: 700, background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 16, overflow: "hidden" }}>
        <DesktopSidebar role={role as "owner" | "trainer" | "superadmin"} page={currentPage} onNavigate={setPage} userLabel={userLabel} onLogout={onLogout} />
        <main style={{ flex: 1, padding: "24px 28px", overflowY: "auto" }}>{pageMap[currentPage]}</main>
      </div>
    </>
  );
}

function RolePicker({ role, onSwitch, allowSuperAdmin }: { role: AppRole; onSwitch: (r: AppRole) => void; allowSuperAdmin: boolean }) {
  const allRoles: { id: AppRole; label: string; icon: string }[] = [
    { id: "owner", label: "Gym Owner", icon: "🏢" },
    { id: "trainer", label: "Trainer", icon: "🏋️" },
    { id: "superadmin", label: "Super Admin", icon: "🛡️" },
    { id: "member", label: "Member (mobile)", icon: "🧑" },
  ];
  const roles = allowSuperAdmin ? allRoles : allRoles.filter((r) => r.id !== "superadmin");
  return (
    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 18 }}>
      {roles.map((r) => (
        <div key={r.id} onClick={() => onSwitch(r.id)} style={{ fontFamily: fonts.mono, fontSize: 11, letterSpacing: 1, padding: "10px 18px", borderRadius: 999, cursor: "pointer", background: role === r.id ? colors.accent : colors.surface, color: role === r.id ? colors.bg : colors.textLow, fontWeight: role === r.id ? 600 : 400, border: `1px solid ${role === r.id ? colors.accent : colors.border}` }}>
          {r.icon} {r.label}
        </div>
      ))}
    </div>
  );
}

export default VitaForgeApp;
