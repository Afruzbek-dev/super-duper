"use client";
/**
 * VitaForge AI — Demo Auth (public preview build)
 * ─────────────────────────────────────────────────────
 * This build is for the public Vercel preview link — it
 * intentionally has NO external dependency (no Supabase
 * project needed) so the demo works immediately for anyone
 * who opens the link.
 *
 * Owner / Trainer / Member: one-click demo entry.
 * Super Admin: gated behind the fixed credentials below.
 * ───────────────────────────────────────────────────── */

import { useEffect, useState, useCallback } from "react";
import type { AppRole } from "@/components/VitaForgeKit";

const STORAGE_KEY = "vf_demo_session";

export const SUPERADMIN_DEMO_CREDENTIALS = {
  email: "admin@vitaforge.uz",
  password: "VitaForge#2026",
};

export interface AuthSession {
  role: AppRole;
  email: string;
  name: string;
  loggedInAt: string;
}

function readSession(): AuthSession | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as AuthSession) : null;
  } catch {
    return null;
  }
}

function writeSession(session: AuthSession | null) {
  if (typeof window === "undefined") return;
  if (session) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } else {
    window.localStorage.removeItem(STORAGE_KEY);
  }
}

export type LoginResult = { ok: true } | { ok: false; error: string };

export function useAuth() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setSession(readSession());
    setReady(true);
  }, []);

  const loginAsDemoRole = useCallback((role: Exclude<AppRole, "superadmin">, name: string): LoginResult => {
    const demoEmails: Record<string, string> = {
      owner: "botir@fitzone.uz",
      trainer: "aziz@fitzone.uz",
      member: "jasur@example.com",
    };
    const s: AuthSession = { role, email: demoEmails[role], name, loggedInAt: new Date().toISOString() };
    writeSession(s);
    setSession(s);
    return { ok: true };
  }, []);

  const loginAsSuperAdmin = useCallback((email: string, password: string): LoginResult => {
    if (
      email.trim().toLowerCase() !== SUPERADMIN_DEMO_CREDENTIALS.email.toLowerCase() ||
      password !== SUPERADMIN_DEMO_CREDENTIALS.password
    ) {
      return { ok: false, error: "Email yoki parol noto'g'ri" };
    }
    const s: AuthSession = {
      role: "superadmin",
      email: SUPERADMIN_DEMO_CREDENTIALS.email,
      name: "Platform Admin",
      loggedInAt: new Date().toISOString(),
    };
    writeSession(s);
    setSession(s);
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    writeSession(null);
    setSession(null);
  }, []);

  return { session, ready, loginAsDemoRole, loginAsSuperAdmin, logout };
}
