/**
 * VitaForge AI — API Response Types
 * ─────────────────────────────────────────────────────
 * These mirror the Pydantic response_model schemas on the
 * FastAPI backend (see backend/app/schemas/gym.py). Keeping
 * them in sync manually is fine for now; once the API surface
 * stabilizes, consider generating these from the OpenAPI spec
 * (e.g. via `openapi-typescript`).
 * ───────────────────────────────────────────────────── */

export interface KpiDTO {
  label: string;
  value: string;
  delta?: string;
  tone?: "default" | "warn" | "good";
}

export interface TimeSeriesPointDTO {
  label: string;
  value: number;
}

export interface MemberDTO {
  id: string;
  initials: string;
  name: string;
  plan: "Starter" | "Pro" | "Scale" | "Enterprise";
  status: "active" | "risk" | "new" | "paused";
  streak: string;
  score: number;
  joined_at: string;
}

export interface GymDashboardDTO {
  gym_name: string;
  gym_city: string;
  plan_label: string;
  kpis: KpiDTO[];
  weekly_activity: TimeSeriesPointDTO[];
  recent_members: MemberDTO[];
  churn_risk_members: MemberDTO[];
  leaderboard: MemberDTO[];
}

export interface AiInsightDTO {
  id: string;
  tone: "default" | "warn" | "good";
  title: string;
  body: string;
  action_label: string;
  action_route?: string;
}

export interface AiCopilotReplyDTO {
  reply: string;
}
