"use client";
/**
 * Owner Dashboard — connected to FastAPI
 * ─────────────────────────────────────────────────────
 * This is the reference pattern for wiring any VitaForgeKit
 * page to the real backend. Copy this shape for the other
 * pages (Members, Analytics, Challenge, Trainer/*, Admin/*).
 *
 * Backend endpoint expected:
 *   GET /api/v1/gym/dashboard
 *   → GymDashboardDTO (see src/lib/api-types.ts)
 * ───────────────────────────────────────────────────── */

import React, { useEffect, useState } from "react";
import { api, ApiError } from "@/lib/api";
import type { GymDashboardDTO } from "@/lib/api-types";
import {
  colors, fonts, KpiCard, Panel, BarChart, InsightCard, RiskRow,
  Pill, Avatar, RowBetween, statusTone,
} from "@/components/VitaForgeKit";

// ─── SKELETON (shown while loading) ──────────────────────
function DashboardSkeleton() {
  const pulse: React.CSSProperties = {
    background: colors.surface2,
    borderRadius: 12,
    animation: "vf-pulse 1.4s ease-in-out infinite",
  };
  return (
    <div>
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes vf-pulse { 0%,100% { opacity: 1; } 50% { opacity: .4; } }
      `}} />
      <div style={{ ...pulse, height: 28, width: 260, marginBottom: 22 }} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        {[0, 1, 2, 3].map((i) => <div key={i} style={{ ...pulse, height: 88 }} />)}
      </div>
      <div style={{ ...pulse, height: 160, marginBottom: 16 }} />
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <div style={{ ...pulse, height: 280 }} />
        <div style={{ ...pulse, height: 280 }} />
      </div>
    </div>
  );
}

// ─── ERROR STATE ──────────────────────────────────────────
function DashboardError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div style={{ textAlign: "center", padding: "80px 20px" }}>
      <div style={{ fontSize: 32, marginBottom: 12 }}>⚠️</div>
      <div style={{ fontFamily: fonts.display, fontWeight: 600, fontSize: 15, color: colors.textHi, marginBottom: 6 }}>
        Ma&apos;lumotlarni yuklab bo&apos;lmadi
      </div>
      <div style={{ fontSize: 12, color: colors.textDim, marginBottom: 18 }}>{message}</div>
      <button
        onClick={onRetry}
        style={{ background: colors.accent, color: colors.bg, border: "none", borderRadius: 10, padding: "10px 20px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}
      >
        Qayta urinish
      </button>
    </div>
  );
}

// ─── DATA HOOK ────────────────────────────────────────────
function useGymDashboard() {
  const [data, setData] = useState<GymDashboardDTO | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // TODO: pass real JWT from your auth context, e.g.:
      // const token = await getSupabaseSession();
      const result = await api.get<GymDashboardDTO>("/api/v1/gym/dashboard", {
        // token,
      });
      setData(result);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(`${err.status}: ${err.message}`);
      } else {
        setError("Server bilan bog'lanib bo'lmadi. Backend ishga tushirilganini tekshiring.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { data, error, loading, reload: load };
}

// ─── PAGE ────────────────────────────────────────────────
export default function OwnerDashboardPage() {
  const { data, error, loading, reload } = useGymDashboard();

  if (loading) return <DashboardSkeleton />;
  if (error) return <DashboardError message={error} onRetry={reload} />;
  if (!data) return null;

  return (
    <>
      <RowBetween style={{ marginBottom: 22 }}>
        <div>
          <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>
            Xush kelibsiz 👋
          </div>
          <div style={{ color: colors.textDim, fontSize: 12, marginTop: 2 }}>
            {data.gym_name} · {data.gym_city}
          </div>
        </div>
        <div style={{ background: colors.accentDim, border: `1px solid ${colors.accentBorder}`, color: colors.accent, fontSize: 11, padding: "5px 12px", borderRadius: 999, fontFamily: fonts.mono }}>
          {data.plan_label}
        </div>
      </RowBetween>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        {data.kpis.map((k, i) => <KpiCard key={i} {...k} />)}
      </div>

      {data.churn_risk_members.length > 0 && (
        <InsightCard
          insight={{
            id: "churn-alert",
            tone: "warn",
            title: `🤖 AI Copilot: ${data.churn_risk_members.length} ta a'zo bugun ayniqsa xavfli holatda`,
            body: `${data.churn_risk_members.map((m) => m.name).join(", ")} — barchasi checkin qilmagan. Copilot'da batafsil ko'ring.`,
            actionLabel: "Copilot'da batafsil ko'rish →",
            onAction: () => (window.location.href = "/owner/copilot"),
          }}
        />
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, marginTop: 6 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel title="HAFTALIK FAOLLIK">
            <BarChart data={data.weekly_activity} />
          </Panel>

          <Panel title="SO'NGGI A'ZOLAR">
            <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {["A'ZO", "STREAK", "BALL", "HOLAT"].map((h) => (
                    <th key={h} style={{ textAlign: "left", color: colors.textDim, fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, paddingBottom: 10, borderBottom: `1px solid ${colors.border}` }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.recent_members.map((m) => (
                  <tr key={m.id}>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <Avatar initials={m.initials} />
                        <span style={{ color: colors.textHi }}>{m.name}</span>
                      </div>
                    </td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: m.streak === "0 kun" ? colors.bad : colors.textHi }}>
                      {m.streak}
                    </td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}`, fontFamily: fonts.mono, color: colors.accent }}>
                      {m.score}
                    </td>
                    <td style={{ padding: "11px 8px 11px 0", borderBottom: `1px solid ${colors.surface3}` }}>
                      <Pill label={m.status === "active" ? "Faol" : m.status === "risk" ? "Risk" : "Yangi"} tone={statusTone(m.status)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel title="⚠️ CHURN OGOHLANTIRISH">
            {data.churn_risk_members.map((m) => (
              <RiskRow key={m.id}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: colors.bad }} />
                  {m.name}
                </div>
                <span style={{ fontFamily: fonts.mono, color: colors.bad, fontSize: 11 }}>{m.streak}</span>
              </RiskRow>
            ))}
          </Panel>

          <Panel title="🏆 HAFTALIK TOP">
            {data.leaderboard.map((m, i) => (
              <RiskRow key={m.id}>
                <span style={{ color: i === 0 ? colors.accent : colors.textHi }}>
                  {["🥇", "🥈", "🥉"][i] ?? `${i + 1}.`} {m.name}
                </span>
                <span style={{ fontFamily: fonts.mono, color: i === 0 ? colors.accent : colors.textDim }}>
                  {m.score.toLocaleString()}
                </span>
              </RiskRow>
            ))}
          </Panel>
        </div>
      </div>
    </>
  );
}
