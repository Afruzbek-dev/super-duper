"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth, SUPERADMIN_DEMO_CREDENTIALS } from "@/lib/auth";
import { colors, fonts } from "@/components/VitaForgeKit";

const ROLE_CARDS: Array<{ id: "owner" | "trainer" | "member"; icon: string; title: string; desc: string; name: string }> = [
  { id: "owner", icon: "🏢", title: "Gym Owner", desc: "CRM, a'zolar, retention analytics", name: "Botir Niyozov" },
  { id: "trainer", icon: "🏋️", title: "Trainer", desc: "Mijozlar, jadval, AI Copilot", name: "Coach Aziz" },
  { id: "member", icon: "🧑", title: "Member", desc: "Mobil ilova — mashq, ovqat, AI Trener", name: "Jasur Tashkentov" },
];

export default function LoginPage() {
  const router = useRouter();
  const { loginAsDemoRole, loginAsSuperAdmin } = useAuth();

  const [mode, setMode] = useState<"pick" | "superadmin">("pick");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [showCreds, setShowCreds] = useState(false);

  const handleRolePick = (roleId: "owner" | "trainer" | "member", name: string) => {
    loginAsDemoRole(roleId, name);
    router.push("/");
  };

  const handleSuperAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = loginAsSuperAdmin(email, password);
    if (result.ok) {
      router.push("/");
    } else {
      setError(result.error);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: colors.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 20px", fontFamily: fonts.body }}>
      <div style={{ width: "100%", maxWidth: 440 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 28 }}>
          <div style={{ width: 36, height: 36, background: colors.accent, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: fonts.display, fontWeight: 900, color: colors.bg, fontSize: 17 }}>V</div>
          <span style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 20, color: colors.textHi }}>VitaForge AI</span>
        </div>

        <div style={{ background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 20, padding: 28 }}>
          {mode === "pick" ? (
            <>
              <div style={{ textAlign: "center", marginBottom: 22 }}>
                <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 17, color: colors.textHi, marginBottom: 6 }}>Rolni tanlang</div>
                <div style={{ fontSize: 12, color: colors.textDim, lineHeight: 1.6 }}>Demo sifatida istalgan rol bilan kirib, barcha funksiyalarni sinab ko&apos;ring</div>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 18 }}>
                {ROLE_CARDS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => handleRolePick(r.id, r.name)}
                    style={{ display: "flex", alignItems: "center", gap: 14, background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 14, padding: "14px 16px", cursor: "pointer", textAlign: "left", width: "100%" }}
                  >
                    <span style={{ fontSize: 26 }}>{r.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: fonts.display, fontWeight: 600, fontSize: 13, color: colors.textHi }}>{r.title}</div>
                      <div style={{ fontSize: 11, color: colors.textDim, marginTop: 2 }}>{r.desc}</div>
                    </div>
                    <span style={{ color: colors.textDim, fontSize: 14 }}>→</span>
                  </button>
                ))}
              </div>

              <div style={{ height: 1, background: colors.surface3, margin: "6px 0 16px" }} />

              <button
                onClick={() => { setMode("superadmin"); setError(null); }}
                style={{ width: "100%", background: "transparent", border: `1px solid ${colors.border2}`, color: colors.textMid, fontSize: 12, fontWeight: 500, padding: 11, borderRadius: 12, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
              >
                🛡️ Super Admin sifatida kirish
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => { setMode("pick"); setError(null); }}
                style={{ background: "none", border: "none", color: colors.textDim, fontFamily: fonts.mono, fontSize: 11, cursor: "pointer", marginBottom: 16, padding: 0 }}
              >
                ← Ortga
              </button>

              <div style={{ textAlign: "center", marginBottom: 22 }}>
                <div style={{ fontSize: 26, marginBottom: 8 }}>🛡️</div>
                <div style={{ fontFamily: fonts.display, fontWeight: 700, fontSize: 17, color: colors.textHi, marginBottom: 6 }}>Super Admin</div>
                <div style={{ fontSize: 12, color: colors.textDim, lineHeight: 1.6 }}>Platforma darajasidagi kirish — faqat vakolatli xodimlar uchun</div>
              </div>

              <form onSubmit={handleSuperAdminSubmit}>
                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, color: colors.textDim, marginBottom: 6, display: "block" }}>EMAIL</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@vitaforge.uz"
                    required
                    style={{ width: "100%", background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: "11px 14px", fontSize: 13, color: colors.textHi, fontFamily: fonts.body, outline: "none" }}
                  />
                </div>
                <div style={{ marginBottom: 8 }}>
                  <label style={{ fontFamily: fonts.mono, fontSize: 10, letterSpacing: 1, color: colors.textDim, marginBottom: 6, display: "block" }}>PAROL</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    required
                    style={{ width: "100%", background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: "11px 14px", fontSize: 13, color: colors.textHi, fontFamily: fonts.body, outline: "none" }}
                  />
                </div>

                {error && <div style={{ fontSize: 11, color: colors.bad, marginBottom: 12, marginTop: 8 }}>⚠️ {error}</div>}

                <button
                  type="submit"
                  style={{ width: "100%", background: colors.accent, color: colors.bg, fontWeight: 600, fontSize: 13, padding: 13, borderRadius: 12, border: "none", cursor: "pointer", marginTop: 14, boxShadow: "0 0 18px rgba(232,255,71,0.22)" }}
                >
                  Kirish
                </button>
              </form>

              <div style={{ marginTop: 16, textAlign: "center" }}>
                <button
                  onClick={() => setShowCreds((v) => !v)}
                  style={{ background: "none", border: "none", color: colors.info, fontSize: 11, cursor: "pointer", fontFamily: fonts.mono }}
                >
                  {showCreds ? "Yashirish" : "Demo login ma'lumotlarini ko'rsatish"}
                </button>
                {showCreds && (
                  <div style={{ marginTop: 10, background: colors.surface2, border: `1px solid ${colors.border}`, borderRadius: 10, padding: 12, fontSize: 11, color: colors.textMid, textAlign: "left", lineHeight: 1.8 }}>
                    <div>
                      <span style={{ color: colors.textDim }}>Email:</span>{" "}
                      <span style={{ fontFamily: fonts.mono, color: colors.accent }}>{SUPERADMIN_DEMO_CREDENTIALS.email}</span>
                    </div>
                    <div>
                      <span style={{ color: colors.textDim }}>Parol:</span>{" "}
                      <span style={{ fontFamily: fonts.mono, color: colors.accent }}>{SUPERADMIN_DEMO_CREDENTIALS.password}</span>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <div style={{ textAlign: "center", fontSize: 10, color: colors.textDim, marginTop: 18, lineHeight: 1.6 }}>
          Bu jamoat namoyishi — login localStorage&apos;da saqlanadi, real Supabase Auth ishlatilmaydi
        </div>
      </div>
    </div>
  );
}
