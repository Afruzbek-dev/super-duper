"use client";

import { AuthGuard } from "@/components/AuthGuard";
import { VitaForgeApp } from "@/components/VitaForgeKit";

export default function HomePage() {
  return (
    <div style={{ padding: "32px 24px", maxWidth: 1320, margin: "0 auto" }}>
      <AuthGuard>
        {(session, logout) => (
          <VitaForgeApp
            initialRole={session.role}
            userName={session.name}
            userEmail={session.email}
            onLogout={logout}
          />
        )}
      </AuthGuard>
    </div>
  );
}
