import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VitaForge AI",
  description: "AI-powered gym management platform — Owner, Trainer, SuperAdmin & Member",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz">
      <body>{children}</body>
    </html>
  );
}
